// Run on the server's private terminal. Passwords are read without echo.
import {openDatabase} from './database.mjs';
import {randomBytes,randomUUID,scrypt} from 'node:crypto';
import {promisify} from 'node:util';
import {emitKeypressEvents} from 'node:readline';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {existsSync} from 'node:fs';
const path=join(resolve(process.env.DATA_DIR||join(dirname(fileURLToPath(import.meta.url)),'data')),'jonahcraft.sqlite');
if(!existsSync(path))throw Error('Start the game server once to create the database, then run owner-setup.mjs.');
if(!process.stdin.isTTY)throw Error('Use an interactive private terminal. Never pipe an owner password or place it in arguments.');
const db=await openDatabase(path);db.exec('PRAGMA journal_mode=WAL');db.exec('PRAGMA busy_timeout=5000');
if(db.prepare('SELECT value FROM settings WHERE key=?').get('owner_id'))throw Error('An owner already exists. Setup is permanently locked.');
emitKeypressEvents(process.stdin);
function secret(prompt){return new Promise((resolve,reject)=>{let value='';process.stdout.write(prompt);process.stdin.setRawMode(true);process.stdin.resume();const onKey=(s,key)=>{if(key?.ctrl&&key.name==='c'){finish();reject(Error('Cancelled.'));}else if(key?.name==='return'){finish();resolve(value);}else if(key?.name==='backspace'){value=value.slice(0,-1);}else if(s&&!key?.ctrl&&!key?.meta&&value.length<128)value+=s;};function finish(){process.stdin.off('keypress',onKey);process.stdin.setRawMode(false);process.stdin.pause();process.stdout.write('\n');}process.stdin.on('keypress',onKey);});}
try{
 console.log('Create the reserved Jonah owner account. Enter your password here privately. Input is hidden.');
 const password=await secret('Initial owner password (12–128 characters): '),confirm=await secret('Confirm password: ');
 if(password.length<12||password.length>128||Buffer.byteLength(password)>256)throw Error('Use 12–128 characters, maximum 256 bytes.');if(password!==confirm)throw Error('Passwords did not match.');
 const salt=randomBytes(16).toString('hex'),hash=(await promisify(scrypt)(password,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024})).toString('hex'),id=randomUUID();
 db.exec('BEGIN IMMEDIATE');try{if(db.prepare('SELECT value FROM settings WHERE key=?').get('owner_id'))throw Error('Owner already configured.');db.prepare('INSERT INTO users(id,username,salt,password,allowed,created) VALUES(?,?,?,?,1,?)').run(id,'Jonah',salt,hash,Date.now());db.prepare('INSERT INTO settings VALUES(?,?)').run('owner_id',id);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
 console.log('Owner account created. Log in as Jonah. Privileges are bound to your account ID.');
}catch(e){console.error(e.message);process.exitCode=1;}finally{db.close();}
