// Publish the same live game to the two existing arcades without redeploying them.
// The creator password is accepted only from hidden stdin, never arguments/files.
import {emitKeypressEvents} from 'node:readline';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';

export const SITES=['https://jonahsgames.netlify.app','https://jonahsgames2.netlify.app'];
export async function publishBoth({gameURL,password,fetchImpl=fetch,log=console.log}){
 const u=new URL(gameURL);if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash)throw Error('Use the live HTTPS game origin, without credentials, a query or fragment.');
 if(u.pathname!=='/')throw Error('Use the game server origin, without a page path.');
 const address=u.origin+'/',sessions=[],published=[];
 const json=async(url,options={})=>{const r=await fetchImpl(url,{...options,signal:AbortSignal.timeout(30000)}),v=await r.json().catch(()=>({}));if(!r.ok)throw Error(`${new URL(url).host}: ${r.status} ${v.error||'Request failed'}`);return {r,v};};
 const status=(await json(u.origin+'/api/status')).v;
 if(status.ok!==true||typeof status.version!=='string'||status.ownerConfigured!==true)throw Error('The live JonahCraft server must be working and its private Jonah owner setup must be complete before publication.');
 if(typeof password!=='string'||!password)throw Error('The existing arcade Creator password is required on hidden stdin.');
 try{
  // Authenticate and prepare BOTH targets before making any catalog changes.
  for(const origin of SITES){
   const before=(await json(origin+'/api/arcade/catalog')).v;if(!Array.isArray(before))throw Error('Unexpected catalog response.');
   const {r}=await json(origin+'/api/arcade/login',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({username:'Jonah',password})});
   const cookie=r.headers.getSetCookie().find(s=>s.startsWith('jonah_creator='))?.split(';')[0];if(!cookie)throw Error('Creator login did not establish a secure session.');
   const session={origin,cookie,before};sessions.push(session);
   const catalog=(await json(origin+'/api/arcade/catalog',{headers:{Cookie:cookie}})).v;
   const matches=catalog.filter(g=>g.title?.trim().toLowerCase()==='jonahcraft');if(matches.length>1)throw Error('Multiple JonahCraft entries exist; resolve them before publishing.');
   session.existing=matches[0];
  }
  for(const s of sessions){
   const payload={...(s.existing?{id:s.existing.id,revision:s.existing.revision||'seed'}:{}),title:'JonahCraft',genre:'Other',visibility:'public',description:'An original 3D voxel sandbox with seed-based worlds, Survival and Creative, secure accounts, saved progress, multiplayer, crafting, creatures, and Nether travel. Opens the shared game server.',link:address};
   const {v}=await json(s.origin+'/api/arcade/save',{method:'POST',headers:{Origin:s.origin,Cookie:s.cookie,'Content-Type':'application/json'},body:JSON.stringify(payload)});
   published.push({site:s.origin,id:v.id,gameURL:address});
   const after=(await json(s.origin+'/api/arcade/catalog')).v,entry=after.find(g=>g.id===v.id);
   if(!entry||entry.kind!=='link'||entry.playUrl!==address||entry.visibility!=='public')throw Error('Saved entry did not appear correctly in the public catalog.');
   for(const old of s.before)if(old.id!==v.id&&JSON.stringify(after.find(g=>g.id===old.id))!==JSON.stringify(old))throw Error('An unrelated public catalog entry changed; inspect concurrent edits.');
   log('Published and verified JonahCraft on '+s.origin);
  }
  return published;
 }catch(e){if(published.length)e.message+=' Already updated: '+published.map(p=>p.site).join(', ');throw e;
 }finally{for(const s of sessions)await fetchImpl(s.origin+'/api/arcade/logout',{method:'POST',headers:{Origin:s.origin,Cookie:s.cookie,'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(10000)}).catch(()=>{});}
}
async function privateInput(){
 if(!process.stdin.isTTY)throw Error('Run this in a private interactive terminal; do not place a password in arguments or a file.');
 emitKeypressEvents(process.stdin);process.stdin.setRawMode(true);process.stdin.resume();
 process.stdout.write('Existing Jonah’s Games Creator password (hidden; not your JonahCraft password): ');
 return new Promise((resolve,reject)=>{let value='';const handler=(text,key)=>{if(key?.ctrl&&key.name==='c'){end();reject(Error('Cancelled.'));}else if(key?.name==='return'){end();resolve(value);}else if(key?.name==='backspace')value=value.slice(0,-1);else if(text&&!key?.ctrl&&!key?.meta&&value.length<256)value+=text;};function end(){process.stdin.off('keypress',handler);process.stdin.setRawMode(false);process.stdin.pause();process.stdout.write('\n');}process.stdin.on('keypress',handler);});
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const gameURL=process.argv[2];if(!gameURL)throw Error('Usage: node integration/publish-both.mjs https://YOUR-LIVE-GAME-SERVER');console.log('Targets: '+SITES.join(' and '));const password=await privateInput();await publishBoth({gameURL,password});}catch(e){console.error(e.message);process.exitCode=1;}
}
