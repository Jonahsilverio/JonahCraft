// Set this to the HTTPS address of the deployed game server, then redeploy the arcade.
export const GAME_URL = '';
