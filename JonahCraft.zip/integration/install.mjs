import {copyFileSync,readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const [directory,address]=process.argv.slice(2),here=dirname(fileURLToPath(import.meta.url));
if(!directory||!address)throw Error('Usage: node integration/install.mjs /path/to/arcade/public https://game.example.com');
const u=new URL(address);if(u.protocol!=='https:'||u.username||u.password)throw Error('Use an HTTPS game server URL without credentials.');
const target=resolve(directory),index=join(target,'index.html');if(!existsSync(index))throw Error('Arcade public/index.html was not found.');
let html=readFileSync(index,'utf8');const script='<script type="module" src="/jonahcraft-button.js"></script>';
if(!html.includes('/jonahcraft-button.js')){copyFileSync(index,join(target,'index.before-jonahcraft.html'));html=html.replace('</head>','  '+script+'\n</head>');writeFileSync(index,html);}
copyFileSync(join(here,'jonahcraft-button.js'),join(target,'jonahcraft-button.js'));
writeFileSync(join(target,'jonahcraft-config.js'),'export const GAME_URL = '+JSON.stringify(u.href)+';\n');
console.log('Play JonahCraft added to the arcade source. Redeploy the arcade to publish it.');
