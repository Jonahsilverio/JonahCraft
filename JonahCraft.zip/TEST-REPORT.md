# JonahCraft 0.1.0 — verification

Date: November 16, 2026. Environment: Windows, Node.js v24.22.1, SQLite from Node's standard library, browser WebGL.

## Automated integration run

Command: `node --test test/game.test.mjs`.

Final completed full integration run: **3 tests passed, 0 failed**, 29.20 seconds. These three tests contain the assertions listed below; this is not a claim of three independent browser sessions or a load benchmark. The exact output is included in `test-result.txt`.

The test creates its own temporary storage and real listening server. It creates an isolated test owner with a random password and two independent authenticated HTTP clients. These credentials and the test database are not delivered in the release.

Verified:

- Stable terrain for matching seeds, positive/negative chunks, and both dimensions; different seeds differ. Coal, iron, gold, redstone, lapis, diamond, water, lava and trees occur in sampled chunks. Bedrock floor exists.
- Inventory addition/removal, stack counts, rejection of overflow, collision, landing, and fall damage.
- Owner setup locks after first use; case-insensitive public registration cannot claim Jonah. Owner identity is a server-generated account ID.
- Creating a regular account, logging out, rejecting a wrong password, logging in again case-insensitively, and rotating the session token.
- Rejecting cross-origin authenticated POSTs and denying non-owner access to the owner endpoint.
- Denying every requested owner command to a normal account: gamemode, give, tp, time, weather, summon, kick, ban, unban, whitelist, save.
- Joining the same world with two authenticated clients; both see the player list, chat and the same mined-block update.
- Crafting planks and a crafting table; rejecting a recipe without ingredients; placing the table and crafting a stone pickaxe nearby.
- Requiring mining start, enforcing mining time in Survival, saving the changed block, and creating or automatically picking up the drop.
- Chest placement, depositing and withdrawing items; furnace placement, fuel use, timed smelting, collecting iron output.
- Server-simulated movement; supplied health and position fields are ignored.
- Summoning and defeating a pig with a weapon, and removing the defeated creature from the shared state.
- Constructing a lit portal with a portal core; entering the Nether; waiting out cooldown and returning to the Overworld.
- Fall-induced death, clearing/dropping inventory, and respawning with restored health at the Overworld spawn.
- Creating a world backup, restoring it, removing changes made after the backup, and requiring a rejoin.
- Ban, unban, session revocation, whitelist denial and restoring access by account.
- Explicit save, server process restart, account login, and reloading player inventory, dimension, edited terrain and chest storage.
- Database verification that the password field is a 64-byte derived hash with a separate random salt; the stored owner ID matches the authenticated owner account.

During development these tests caught an overly strict block-visibility check and assumptions about creature damage, instant pickup and rate limits. The final release-source run passed, and those exact files are packaged with the test log. The arcade integration installer was also run against an isolated HTML fixture: existing content was retained and running it twice did not duplicate the script.

## Browser checks

The actual browser rendered the textured 3D terrain and menus. A disposable non-owner test account logged in, survived a page reload and server restart, and rejoined a saved world. These test accounts/worlds are excluded from the delivery.

Checked through visible UI:

- Landing screen, authentication screen, shared-world list and Survival world loading.
- WASD movement with changing saved coordinates; inventory and recipe controls.
- Creating a named world from an entered seed in Creative mode.
- Selecting Creative building blocks, right-click placement, held-left-click mining, hotbar counts and selected item display.
- Keyboard look fallback and Creative flight.
- Reloading and rejoining with the same position and inventory.
- Visible blocky terrain, trees, snowy mountains, a ravine and original animal models.

A browser test found stale chunk responses could briefly reappear after a mined block. The client now discards snapshots overtaken by actions, overlays confirmed local edits until a fresh mesh arrives, and paces mining transitions. The placement/mining sequence was repeated in-browser successfully after the fix.

The embedded preview browser rejected pointer lock with a document restriction. Keyboard look was used for these checks. A separate regular-Chrome mouse-look check was attempted, but computer control stopped because it could not verify the current browser address. **Mouse capture in ordinary Chrome therefore remains unverified**, despite the standard Pointer Lock implementation. No rendering/shader errors were observed in the checked browser view.

## Not verified

Follow-up for both websites: `node --test test/publish.test.mjs` passed all three mock tests. The publisher handles both real site addresses, repeat publication without duplicates, preservation of other games, failure of second-site authentication before any publication, and rejection of an unfinished owner setup before transmitting arcade credentials. Both live homepages returned HTTP 200 on the follow-up check. No live catalog writes were made because Render remains unconnected.

- Public Render deployment, persistent disk behavior on Render, live HTTPS cookies, or the live Jonah's Games Play button. Render is selected, but its account integration is not yet connected.
- Docker image build/Compose startup; the host has not executed these deployment files.
- Actual Chromebook hardware performance, mobile/touch, large concurrent player counts or multiplayer over the public internet.
- Full AI behavior for every creature, a full Survival playthrough, all armor combinations, every ore distribution over a large sample, all portal placements, or every owner-panel button in a live browser. Shared mechanisms have integration coverage, but that is not exhaustive coverage.
- External security audit, penetration test, account recovery or disaster recovery of a failed physical disk.

The feature differences and unfinished functionality are listed explicitly in README.md under “Tests and release limits.”
