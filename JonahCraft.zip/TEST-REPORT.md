# JonahCraft 0.4.0 validation

- 17 automated cases passed across the suite and the integration rerun: collision sweep/floors/ceilings/negative coordinates/flight, saved-position recovery, chunk revision ordering, a real worker race, generation, inventory, accounts/owner authorization, singleplayer access and pausing, multiplayer, mining/crafting/furnace/combat, Nether, backups and restart.
- The delayed-chunk test was run against the old worker first and failed: a newer stone block became air. It passes after the revision fix.
- The first extended server fixture placed its test wall behind an existing crafting table and was correctly rejected by line-of-sight validation. Moving the fixture to a clear lane made the full integration pass; line-of-sight protections were preserved.
- Browser: sustained walking, sprinting and Creative flight stop at x=15.70 before a wall at x=16, including authoritative state polling. Local collision proof is delivered separately.
- Eighteen chunks from three seeds, positive/negative coordinates and both dimensions exactly match 0.3.1 terrain data.
- The preview database, test wall, browser sessions and fixture account are local only and excluded from this archive. Public deployment verification is recorded separately with the delivery.

Run all tests with npm test or node --test test/*.test.mjs using Node 24. Actual Chromebook hardware and large multiplayer load were not benchmarked.
