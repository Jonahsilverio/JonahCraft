import http from 'node:http';
import {openDatabase} from './database.mjs';
import {randomBytes,randomUUID,scrypt,timingSafeEqual,createHash} from 'node:crypto';
import {promisify} from 'node:util';
import {readFileSync,writeFileSync,mkdirSync,existsSync,readdirSync,statSync} from 'node:fs';
import {resolve,dirname,extname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync} from 'node:zlib';
import {B,BLOCKS,ITEMS,MOBS,RECIPES,SMELT,HEIGHT,Terrain,index,local,newPlayer,physics,raycast,direction,miningSeconds,solid,collides,addItem,removeItem,countItem,slug,hash} from './public/shared/game.js';
const root=dirname(fileURLToPath(import.meta.url)),data=resolve(process.env.DATA_DIR||join(root,'data'));
mkdirSync(data,{recursive:true});mkdirSync(join(data,'backups'),{recursive:true});
const db=await openDatabase(join(data,'jonahcraft.sqlite'));
// Execute each schema statement separately: remote libSQL stops an exec batch
// after a PRAGMA result, while local SQLite continues through the whole batch.
for(const sql of `PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT NOT NULL COLLATE NOCASE UNIQUE,salt TEXT NOT NULL,password TEXT NOT NULL,banned INTEGER DEFAULT 0,allowed INTEGER DEFAULT 0,created INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),expires INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS worlds(id TEXT PRIMARY KEY,name TEXT NOT NULL,seed TEXT NOT NULL,mode TEXT NOT NULL,creator TEXT,state TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS players(user_id TEXT REFERENCES users(id),world_id TEXT REFERENCES worlds(id),state TEXT NOT NULL,PRIMARY KEY(user_id,world_id));
 CREATE TABLE IF NOT EXISTS edits(world_id TEXT REFERENCES worlds(id),dimension TEXT,x INTEGER,y INTEGER,z INTEGER,block INTEGER NOT NULL,PRIMARY KEY(world_id,dimension,x,y,z));
 CREATE TABLE IF NOT EXISTS entities(world_id TEXT,position TEXT,state TEXT NOT NULL,PRIMARY KEY(world_id,position));
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,time INTEGER,actor TEXT,action TEXT);
 CREATE TABLE IF NOT EXISTS backups(id TEXT PRIMARY KEY,world_id TEXT NOT NULL,created INTEGER NOT NULL,state TEXT NOT NULL);
`.split(';').map(s=>s.trim()).filter(Boolean))db.exec(sql);
const stmt=s=>db.prepare(s),setting=k=>stmt('SELECT value FROM settings WHERE key=?').get(k)?.value;
const putSetting=(k,v)=>stmt('INSERT OR REPLACE INTO settings VALUES(?,?)').run(k,v);
const sha=s=>createHash('sha256').update(s).digest('hex'),derive=promisify(scrypt);
const ownerID=()=>setting('owner_id');
const port=Number(process.env.PORT||8088),host=process.env.HOST||'127.0.0.1';
const setupEnabled=process.argv.includes('--setup');
if(setupEnabled&&host!=='127.0.0.1')throw Error('Owner setup must bind to 127.0.0.1. Use a local session or SSH tunnel.');
const configuredURL=process.env.PUBLIC_URL||process.env.RENDER_EXTERNAL_URL;
if(process.env.NODE_ENV==='production'&&!configuredURL?.startsWith('https://'))throw Error('Production requires PUBLIC_URL=https://your-game-domain or Render’s HTTPS service URL.');
const publicOrigin=configuredURL?new URL(configuredURL).origin:`http://127.0.0.1:${port}`;
const remoteSetupToken=process.env.OWNER_SETUP_TOKEN;
if(remoteSetupToken&&(!/^[-_A-Za-z0-9+/=]{43,128}$/.test(remoteSetupToken)||!publicOrigin.startsWith('https://')))throw Error('Remote owner setup requires a cryptographically random secret containing at least 32 bytes and HTTPS.');
const remoteSetup=!!remoteSetupToken;
const setupToken=!ownerID()?(remoteSetupToken||(setupEnabled?randomBytes(32).toString('hex'):null)):null,setupExpires=Date.now()+15*60000;
const worlds=new Map(),online=new Map(),limits=new Map();let authBusy=0;
function fail(message,status=400){throw Object.assign(Error(message),{status});}
function rate(key,max,windowMs){const now=Date.now();let v=limits.get(key);if(!v||now-v.t>windowMs){v={t:now,n:0};limits.set(key,v);}if(++v.n>max)fail('Too many attempts. Try again later.',429);}
function audit(user,action){stmt('INSERT INTO audit(time,actor,action) VALUES(?,?,?)').run(Date.now(),user.id,action);}
function isOwner(u){return !!u&&u.id===ownerID();}
function requireOwner(u){if(!isOwner(u))fail('Owner account required.',403);}
function clientIP(req){return process.env.TRUST_PROXY==='1'?String(req.headers['x-forwarded-for']||req.socket.remoteAddress).split(',').at(-1).trim():req.socket.remoteAddress;}
function session(req){const raw=String(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('jc_session='))?.slice(11);if(!/^[a-f0-9]{64}$/.test(raw||''))return null;const token=sha(raw);const u=stmt('SELECT u.*,s.expires FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?').get(token);if(!u||u.expires<Date.now()||u.banned)return null;return {...u,session:token};}
function needUser(req){const u=session(req);if(!u)fail('Log in to continue.',401);if(setting('whitelist')==='on'&&!isOwner(u)&&!u.allowed)fail('The server whitelist is enabled. Ask Jonah to add your account.',403);return u;}
function info(u){return {id:u.id,username:u.username,owner:isOwner(u)};}
function cookie(token,expired=false){return `jc_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${expired?0:604800}${publicOrigin.startsWith('https:')?'; Secure':''}`;}
async function passwordHash(password,salt){if(authBusy>=4)fail('Server is busy. Try again shortly.',503);authBusy++;try{return (await derive(password,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024})).toString('hex');}finally{authBusy--;}}
function checkPassword(p){if(typeof p!=='string'||p.length<12||p.length>128||Buffer.byteLength(p)>256)fail('Use a password of 12–128 characters (maximum 256 bytes).');}
function validateName(n){if(typeof n!=='string'||!/^[A-Za-z][A-Za-z0-9_]{2,19}$/.test(n))fail('Username: 3–20 letters, numbers or underscores; start with a letter.');}
function authenticate(u,res){const token=randomBytes(32).toString('hex');stmt('INSERT INTO sessions VALUES(?,?,?)').run(sha(token),u.id,Date.now()+7*86400000);res.setHeader('Set-Cookie',cookie(token));return info(u);}
function transaction(fn){db.exec('BEGIN IMMEDIATE');try{let r=fn();db.exec('COMMIT');return r;}catch(e){db.exec('ROLLBACK');throw e;}}
function createWorld(name,seed,mode,creator){const id=randomUUID(),state={time:6000,weather:'clear',revision:0,mobs:[],drops:[],portals:[]};stmt('INSERT INTO worlds VALUES(?,?,?,?,?,?)').run(id,name,seed,mode,creator,JSON.stringify(state));return id;}
if(!stmt('SELECT id FROM worlds LIMIT 1').get())createWorld('Jonah’s shared world','Jonahs-Games-2026','survival',null);
function world(id){if(worlds.has(id))return worlds.get(id);const r=stmt('SELECT * FROM worlds WHERE id=?').get(id);if(!r)fail('World not found.',404);const w={...r,...JSON.parse(r.state),terrain:new Terrain(r.seed),chunks:new Map(),changes:[],edits:new Map(),blockEntities:new Map()};for(const e of stmt('SELECT * FROM edits WHERE world_id=?').all(id))w.edits.set(`${e.dimension}:${e.x},${e.y},${e.z}`,e.block);for(const e of stmt('SELECT * FROM entities WHERE world_id=?').all(id))w.blockEntities.set(e.position,JSON.parse(e.state));worlds.set(id,w);return w;}
function chunk(w,cx,cz,dim){const key=`${dim}:${cx},${cz}`;if(w.chunks.has(key))return w.chunks.get(key);const a=w.terrain.generate(cx,cz,dim);for(let y=0;y<HEIGHT;y++)for(let z=0;z<16;z++)for(let x=0;x<16;x++){const e=w.edits.get(`${dim}:${cx*16+x},${y},${cz*16+z}`);if(e!==undefined)a[index(x,y,z)]=e;}if(w.chunks.size>256)w.chunks.delete(w.chunks.keys().next().value);w.chunks.set(key,a);return a;}
function get(w,d,x,y,z){if(y<0)return B.BEDROCK;if(y>=HEIGHT)return 0;return chunk(w,Math.floor(x/16),Math.floor(z/16),d)[index(local(x),y,local(z))];}
function set(w,d,x,y,z,b){if(y<1||y>=HEIGHT-1)return;chunk(w,Math.floor(x/16),Math.floor(z/16),d)[index(local(x),y,local(z))]=b;w.edits.set(`${d}:${x},${y},${z}`,b);stmt('INSERT OR REPLACE INTO edits VALUES(?,?,?,?,?,?)').run(w.id,d,x,y,z,b);w.changes.push({r:++w.revision,d,x,y,z,b});if(w.changes.length>6000)w.changes.splice(0,1000);}
function savePlayer(a){stmt('INSERT OR REPLACE INTO players VALUES(?,?,?)').run(a.user.id,a.w.id,JSON.stringify(a.p));}
function saveWorld(w){const state={time:w.time,weather:w.weather,revision:w.revision,mobs:w.mobs,drops:w.drops,portals:w.portals};stmt('UPDATE worlds SET state=? WHERE id=?').run(JSON.stringify(state),w.id);for(const [k,v] of w.blockEntities)stmt('INSERT OR REPLACE INTO entities VALUES(?,?,?)').run(w.id,k,JSON.stringify(v));}
function backupText(name){return stmt('SELECT state FROM backups WHERE id=?').get(name)?.state??(existsSync(join(data,'backups',name))?readFileSync(join(data,'backups',name),'utf8'):null);}
function backupNames(){return [...new Set([...stmt('SELECT id FROM backups').all().map(r=>r.id),...readdirSync(join(data,'backups')).filter(s=>s.endsWith('.json'))])].sort().reverse();}
function saveAll(){transaction(()=>{for(const a of online.values())savePlayer(a);for(const w of worlds.values())saveWorld(w);});}
function active(u){const a=online.get(u.id);if(!a||a.session!==u.session)fail('Join a world first.',409);a.lastSeen=Date.now();return a;}
function view(a){return {...a.p,owner:isOwner(a.user),username:a.user.username};}
function drop(w,d,x,y,z,id,n=1,dur){if(w.drops.length>=512)w.drops.shift();w.drops.push({id:randomUUID(),item:id,n,...(dur?{dur}:{}),x,y:y+.3,z,dimension:d,expires:Date.now()+300000});}
function hurt(a,n){if(a.p.mode==='creative'||a.p.health<=0)return;const defense=Object.values(a.p.armor).reduce((s,q)=>s+(ITEMS[q]?.defense||0),0);a.p.health=Math.max(0,a.p.health-Math.max(1,Math.round(n*(1-Math.min(.8,defense*.04)))));}
function death(a){if(a.p.health>0||a.dead)return;a.dead=true;a.p.deaths++;for(const s of a.p.inventory)if(s)drop(a.w,a.p.dimension,a.p.x,a.p.y,a.p.z,s.id,s.n,s.dur);a.p.inventory=Array(36).fill(null);for(const id of Object.values(a.p.armor))drop(a.w,a.p.dimension,a.p.x,a.p.y,a.p.z,id);a.p.armor={};savePlayer(a);}
function nearBlock(a,id,r=4){const p=a.p;for(let y=Math.floor(p.y)-2;y<=Math.floor(p.y)+2;y++)for(let x=Math.floor(p.x)-r;x<=Math.floor(p.x)+r;x++)for(let z=Math.floor(p.z)-r;z<=Math.floor(p.z)+r;z++)if(get(a.w,p.dimension,x,y,z)===id)return true;return false;}
function target(a,c,max=6){
 if(![c.x,c.y,c.z].every(Number.isInteger)||c.y<1||c.y>=HEIGHT-1)fail('Invalid block.');
 if(Math.hypot(a.p.x-c.x-.5,a.p.y+1.3-c.y-.5,a.p.z-c.z-.5)>max)fail('That block is too far away.');
 const origin={x:a.p.x,y:a.p.y+1.62,z:a.p.z},id=get(a.w,a.p.dimension,c.x,c.y,c.z);
 if(!id)return id;
 // Aim at visible faces. A ray to the centre can pass through adjacent floor blocks.
 for(const [dx,dy,dz] of [[0,.499,0],[0,-.499,0],[.499,0,0],[-.499,0,0],[0,0,.499],[0,0,-.499]]){
  const v={x:c.x+.5+dx-origin.x,y:c.y+.5+dy-origin.y,z:c.z+.5+dz-origin.z},l=Math.hypot(v.x,v.y,v.z),hit=raycast((x,y,z)=>get(a.w,a.p.dimension,x,y,z),origin,{x:v.x/l,y:v.y/l,z:v.z/l},l+.1);
  if(hit&&hit.x===c.x&&hit.y===c.y&&hit.z===c.z)return id;
 }fail('A block is in the way.');
}
function toolWear(p){const q=p.inventory[p.selected];if(q?.dur&&--q.dur<=0)p.inventory[p.selected]=null;}
function teleportSafe(a,x,z,d=a.p.dimension){x=Math.floor(x);z=Math.floor(z);let y=d==='overworld'?a.w.terrain.column(x,z).height+1:42;for(let i=0;i<40&&collides((X,Y,Z)=>get(a.w,d,X,Y,Z),x+.5,y,z+.5);i++)y++;a.p.x=x+.5;a.p.y=y+.05;a.p.z=z+.5;a.p.dimension=d;a.p.vy=0;}
function buildPortal(w,d,x,y,z){
 for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++){set(w,d,x+dx,y-1,z+dz,B.OBSIDIAN);for(let dy=0;dy<5;dy++)set(w,d,x+dx,y+dy,z+dz,0);}
 for(let dx=-1;dx<=2;dx++)for(let dy=0;dy<=4;dy++)set(w,d,x+dx,y+dy,z,(dx===-1||dx===2||dy===0||dy===4)?B.OBSIDIAN:B.PORTAL);
 const p={d,x,y:y+1,z};w.portals.push(p);return p;
}
function enterPortal(a){const p=a.p;if(Date.now()<(a.portalCooldown||0))return;a.portalCooldown=Date.now()+5000;const d=p.dimension==='nether'?'overworld':'nether';let portal=a.w.portals.find(q=>q.d===d);if(!portal){const x=d==='nether'?Math.floor(p.x/8):Math.floor(p.x*8),z=d==='nether'?Math.floor(p.z/8):Math.floor(p.z*8),y=d==='nether'?42:a.w.terrain.column(x,z).height+1;portal=buildPortal(a.w,d,x,y,z);}p.dimension=d;p.x=portal.x+.5;p.y=portal.y+.05;p.z=portal.z+1.5;p.vy=0;savePlayer(a);saveWorld(a.w);}
function command(a,text){requireOwner(a.user);const [cmd,...v]=text.trim().slice(1).split(/\s+/);const p=a.p,w=a.w;let victim=online.get(v[0])||[...online.values()].find(t=>t.user.username.toLowerCase()===v[0]?.toLowerCase());const findUser=n=>stmt('SELECT * FROM users WHERE username=? COLLATE NOCASE').get(n||'');
 switch(cmd){
 case 'gamemode':{const m=v[0];if(!['creative','survival'].includes(m))fail('/gamemode creative|survival [player]');const t=v[1]?[...online.values()].find(t=>t.user.username.toLowerCase()===v[1].toLowerCase()):a;if(!t)fail('Player offline.');t.p.mode=m;t.p.flight=false;savePlayer(t);break;}
 case 'give':{let t=a,id=v[0],n=Number(v[1]||1);if(findUser(v[0])){t=victim;id=v[1];n=Number(v[2]||1);}if(!t||!ITEMS[id]||!Number.isInteger(n)||n<1||n>2304)fail('/give [player] item_id [1–2304]');if(!addItem(t.p.inventory,id,n))fail('Inventory full.');savePlayer(t);break;}
 case 'tp':{if(v.length===1){if(!victim)fail('Player offline.');p.dimension=victim.p.dimension;p.x=victim.p.x+1;p.y=victim.p.y;p.z=victim.p.z;}else{let nums=v.map(Number);if(nums.length!==3||!nums.every(Number.isFinite)||Math.abs(nums[0])>1e6||Math.abs(nums[2])>1e6||nums[1]<1||nums[1]>95)fail('/tp x y z OR /tp player');[p.x,p.y,p.z]=nums;p.vy=0;}savePlayer(a);break;}
 case 'time':{const t={day:6000,night:18000,noon:6000,midnight:18000}[v[0]]??Number(v[0]);if(!Number.isFinite(t))fail('/time day|night|0–23999');w.time=((t%24000)+24000)%24000;break;}
 case 'weather':if(!['clear','rain','storm'].includes(v[0]))fail('/weather clear|rain|storm');w.weather=v[0];break;
 case 'summon':{if(!MOBS[v[0]])fail('Unknown mob.');if(w.mobs.length>=96)fail('Mob limit reached.');spawnMob(w,v[0],p.x+3,p.z,p.dimension,p.y);break;}
 case 'kick':if(!victim||isOwner(victim.user))fail('Player unavailable.');savePlayer(victim);online.delete(victim.user.id);stmt('DELETE FROM sessions WHERE user_id=?').run(victim.user.id);break;
 case 'ban':case 'unban':{const u=findUser(v[0]);if(!u||isOwner(u))fail('Account unavailable.');stmt('UPDATE users SET banned=? WHERE id=?').run(cmd==='ban'?1:0,u.id);if(cmd==='ban'){if(victim){savePlayer(victim);online.delete(u.id);}stmt('DELETE FROM sessions WHERE user_id=?').run(u.id);}break;}
 case 'whitelist':if(['on','off'].includes(v[0])){putSetting('whitelist',v[0]);if(v[0]==='on')for(const q of online.values()){const u=findUser(q.user.username);if(!isOwner(u)&&!u.allowed){savePlayer(q);online.delete(u.id);}}}else if(['add','remove'].includes(v[0])){const u=findUser(v[1]);if(!u)fail('Account not found.');stmt('UPDATE users SET allowed=? WHERE id=?').run(v[0]==='add'?1:0,u.id);if(v[0]==='remove'&&setting('whitelist')==='on'&&!isOwner(u)){const q=online.get(u.id);if(q){savePlayer(q);online.delete(u.id);}}}else fail('/whitelist on|off|add NAME|remove NAME');break;
 case 'save':saveAll();break;
 default:fail('Commands: /gamemode /give /tp /time /weather /summon /kick /ban /unban /whitelist /save');
 }
 audit(a.user,text);saveWorld(w);return {message:'Command applied.'};
}
function action(a,c){const p=a.p,w=a.w,d=p.dimension;if(c.op==='respawn'){if(p.health>0)fail('You are still alive.');Object.assign(p,p.spawn,{health:20,hunger:20,oxygen:20,dimension:'overworld',vy:0});a.dead=false;savePlayer(a);return {};}
 if(p.health<=0)fail('Respawn first.');
 if(c.op==='chat'){if(typeof c.text!=='string'||!c.text.trim()||c.text.length>240)fail('Chat is limited to 240 characters.');rate('chat:'+a.user.id,8,10000);if(c.text.startsWith('/'))return command(a,c.text);w.chat??=[];w.chat.push({id:randomUUID(),name:a.user.username,text:c.text.trim(),time:Date.now()});w.chat=w.chat.slice(-50);return {};}
 if(c.op==='select'){if(!Number.isInteger(c.slot)||c.slot<0||c.slot>8)fail('Invalid slot.');p.selected=c.slot;return {};}
 if(c.op==='flight'){if(p.mode!=='creative')fail('Creative flight only.');p.flight=!p.flight;return {};}
 if(c.op==='mine_start'){const id=target(a,c);if(id===B.BEDROCK||id===B.PORTAL||!id)fail('Cannot mine that block.');a.mining={x:c.x,y:c.y,z:c.z,id,start:Date.now(),slot:p.selected,tool:p.inventory[p.selected]?.id};return {};}
 if(c.op==='mine_finish'){
  const id=target(a,c),m=a.mining,tool=p.inventory[p.selected]?.id;
  if(!m||m.x!==c.x||m.y!==c.y||m.z!==c.z||m.id!==id||m.slot!==p.selected||m.tool!==tool)fail('Start mining this block first.');
  if(p.mode!=='creative'&&Date.now()-m.start<miningSeconds(id,tool)*1000-50)fail('Keep mining.');
  const b=BLOCKS[id];if(b.hardness>=999)fail('Cannot mine that block.');
  const ep=`${d}:${c.x},${c.y},${c.z}`,be=w.blockEntities.get(ep);if(be){for(const q of be.inventory||[])if(q)drop(w,d,c.x+.5,c.y,c.z+.5,q.id,q.n,q.dur);if(be.raw)drop(w,d,c.x+.5,c.y,c.z+.5,be.raw);if(be.output)drop(w,d,c.x+.5,c.y,c.z+.5,be.output.id,be.output.n);w.blockEntities.delete(ep);stmt('DELETE FROM entities WHERE world_id=? AND position=?').run(w.id,ep);}
  set(w,d,c.x,c.y,c.z,0);if(p.mode==='survival'){
   if(!b.tier||ITEMS[tool]?.tool==='pickaxe'&&ITEMS[tool].tier>=b.tier){let item=b.drop||slug(b.name);if(id===B.LEAVES)item=hash(c.x,c.y,c.z,w.terrain.seed)>.8?'apple':null;if(item)drop(w,d,c.x+.5,c.y,c.z+.5,item);}
   toolWear(p);p.hunger=Math.max(0,p.hunger-.025);
  }a.mining=null;savePlayer(a);saveWorld(w);return {};
 }
 if(c.op==='place'){
  if(![c.x,c.y,c.z,c.against?.x,c.against?.y,c.against?.z].every(Number.isInteger)||Math.abs(c.x-c.against.x)+Math.abs(c.y-c.against.y)+Math.abs(c.z-c.against.z)!==1)fail('Place on an adjacent block.');
  target(a,c.against);if(!get(w,d,c.against.x,c.against.y,c.against.z))fail('No supporting block.');
  const q=p.inventory[p.selected],id=ITEMS[q?.id]?.block,old=get(w,d,c.x,c.y,c.z);if(!id||[B.BEDROCK,B.PORTAL,B.WATER,B.LAVA].includes(id)||![0,B.WATER,B.LAVA].includes(old)||c.y<1||c.y>HEIGHT-2)fail('Cannot place here.');
  for(const t of online.values())if(t.w===w&&t.p.dimension===d&&Math.abs(t.p.x-(c.x+.5))<.8&&Math.abs(t.p.z-(c.z+.5))<.8&&c.y<t.p.y+1.8&&c.y+1>t.p.y)fail('A player is standing there.');
  set(w,d,c.x,c.y,c.z,id);if(p.mode==='survival'){q.n--;if(!q.n)p.inventory[p.selected]=null;}savePlayer(a);return {};
 }
 if(c.op==='craft'){const r=RECIPES.find(q=>q.out===c.item);if(!r)fail('Unknown recipe.');if(r.table&&!nearBlock(a,B.TABLE))fail('Place a crafting table nearby.');for(const [id,n] of Object.entries(r.in))if(countItem(p.inventory,id)<n)fail('Missing ingredients.');const inv=structuredClone(p.inventory);for(const [id,n] of Object.entries(r.in))removeItem(inv,id,n);if(!addItem(inv,r.out,r.n))fail('Inventory full.');p.inventory=inv;savePlayer(a);return {};}
 if(c.op==='swap'){if(![c.a,c.b].every(n=>Number.isInteger(n)&&n>=0&&n<36))fail('Invalid slots.');[p.inventory[c.a],p.inventory[c.b]]=[p.inventory[c.b],p.inventory[c.a]];savePlayer(a);return {};}
 if(c.op==='creative_item'){if(p.mode!=='creative'||!ITEMS[c.item])fail('Creative items unavailable.');const n=ITEMS[c.item].durability||ITEMS[c.item].armor?1:64;p.inventory[p.selected]={id:c.item,n,...(ITEMS[c.item].durability?{dur:ITEMS[c.item].durability}:{})};savePlayer(a);return {};}
 if(c.op==='equip'){const q=p.inventory[c.slot],it=ITEMS[q?.id];if(!it?.armor)fail('Choose armor.');let old=p.armor[it.armor];p.armor[it.armor]=q.id;p.inventory[c.slot]=old?{id:old,n:1}:null;savePlayer(a);return {};}
 if(c.op==='unequip'){if(!['helmet','chestplate','leggings','boots'].includes(c.slot)||!p.armor[c.slot])fail('No armor in slot.');if(!addItem(p.inventory,p.armor[c.slot]))fail('Inventory full.');delete p.armor[c.slot];savePlayer(a);return {};}
 if(c.op==='drop'){const q=p.inventory[p.selected];if(!q)fail('Empty slot.');drop(w,d,p.x+Math.sin(p.yaw)*1.5,p.y,p.z-Math.cos(p.yaw)*1.5,q.id,1,q.dur);q.n--;if(!q.n)p.inventory[p.selected]=null;savePlayer(a);return {};}
 if(c.op==='eat'){const q=p.inventory[p.selected],food=ITEMS[q?.id]?.food;if(!food)fail('Hold food first.');if(p.hunger>=20)fail('You are full.');rate('eat:'+a.user.id,1,800);p.hunger=Math.min(20,p.hunger+food);q.n--;if(!q.n)p.inventory[p.selected]=null;savePlayer(a);return {};}
 if(c.op==='attack'){const mob=w.mobs.find(m=>m.id===c.mob&&m.dimension===d);if(!mob||Math.hypot(mob.x-p.x,mob.y-p.y,mob.z-p.z)>4.5)fail('Mob out of reach.');rate('attack:'+a.user.id,1,450);const origin={x:p.x,y:p.y+1.5,z:p.z},diff={x:mob.x-origin.x,y:mob.y+.6-origin.y,z:mob.z-origin.z},len=Math.hypot(diff.x,diff.y,diff.z);const wall=raycast((x,y,z)=>get(w,d,x,y,z),origin,{x:diff.x/len,y:diff.y/len,z:diff.z/len},len);if(wall&&wall.distance<len-.5)fail('A block is in the way.');mob.hp-=ITEMS[p.inventory[p.selected]?.id]?.damage||1;mob.angryUntil=Date.now()+10000;toolWear(p);if(mob.hp<=0){drop(w,d,mob.x,mob.y,mob.z,MOBS[mob.kind].drop,1+Math.floor(Math.random()*2));if(mob.kind==='cow')drop(w,d,mob.x,mob.y,mob.z,'leather');if(mob.kind==='chicken')drop(w,d,mob.x,mob.y,mob.z,'feather');w.mobs.splice(w.mobs.indexOf(mob),1);}savePlayer(a);saveWorld(w);return {};}
 if(c.op==='portal'){if(!nearBlock(a,B.PORTAL,2))fail('Stand beside a lit portal.');enterPortal(a);return {};}
 if(c.op==='ignite'){
  const held=p.inventory[p.selected]?.id;if(held==='nether_key'){
   const x=Math.floor(p.x+Math.sin(p.yaw)*4),z=Math.floor(p.z-Math.cos(p.yaw)*4),y=Math.floor(p.y);if(y>HEIGHT-6)fail('Not enough room for a portal.');for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)for(let dy=0;dy<5;dy++){let b=get(w,d,x+dx,y+dy,z+dz);if(b!==0&&b!==B.LEAVES&&b!==B.WATER)fail('The portal needs a clear 5 × 5 space.');}buildPortal(w,d,x,y,z);if(p.mode==='survival')removeItem(p.inventory,'nether_key',1);
  }else if(held==='flint_and_steel'){
   target(a,c);let found=false;for(let ox=-2;ox<=1&&!found;ox++)for(let oy=-4;oy<=0&&!found;oy++){
    const x=c.x+ox,y=c.y+oy,z=c.z;let ok=true;for(let dx=0;dx<4;dx++)for(let dy=0;dy<5;dy++){const b=get(w,d,x+dx,y+dy,z);if((dx===0||dx===3||dy===0||dy===4)?b!==B.OBSIDIAN:b!==0&&b!==B.PORTAL)ok=false;}if(ok){for(let dx=1;dx<3;dx++)for(let dy=1;dy<4;dy++)set(w,d,x+dx,y+dy,z,B.PORTAL);w.portals.push({d,x:x+1,y:y+1,z});found=true;}}
   if(!found)fail('Build a 4 wide × 5 tall obsidian frame with an empty 2 × 3 opening.');
  }else fail('Hold flint and steel or a crafted portal core.');savePlayer(a);saveWorld(w);return {};
 }
 if(c.op==='container'){
  const id=target(a,c,5);if(id!==B.CHEST&&id!==B.FURNACE)fail('Not a container.');const key=`${d}:${c.x},${c.y},${c.z}`;let e=w.blockEntities.get(key);if(!e){e=id===B.CHEST?{inventory:Array(27).fill(null)}:{raw:null,output:null,ready:0};w.blockEntities.set(key,e);}
  if(c.move==='deposit'&&id===B.CHEST){const q=p.inventory[c.slot];if(!q||!Number.isInteger(c.slot))fail('Choose an inventory slot.');if(!addItem(e.inventory,q.id,q.n,q.dur))fail('Chest full.');p.inventory[c.slot]=null;}
  if(c.move==='withdraw'&&id===B.CHEST){const q=e.inventory[c.slot];if(!q||!Number.isInteger(c.slot))fail('Empty chest slot.');if(!addItem(p.inventory,q.id,q.n,q.dur))fail('Inventory full.');e.inventory[c.slot]=null;}
  if(c.move==='smelt'&&id===B.FURNACE){const q=p.inventory[c.slot];if(!q||!SMELT[q.id])fail('Select raw ore, sand, cobblestone or raw food.');if(e.raw||e.output)fail('Collect the furnace output first.');if(countItem(p.inventory,'coal')<1)fail('One coal is needed as fuel.');e.raw=q.id;e.ready=Date.now()+8000;removeItem(p.inventory,q.id,1);removeItem(p.inventory,'coal',1);}
  if(c.move==='take'&&id===B.FURNACE){finishFurnace(e);if(!e.output)fail('Still smelting.');if(!addItem(p.inventory,e.output.id,e.output.n))fail('Inventory full.');e.output=null;}
  savePlayer(a);saveWorld(w);return {container:e,type:id};
 }
 fail('Unknown action.');
}
function finishFurnace(e){if(e.raw&&Date.now()>=e.ready){e.output={id:SMELT[e.raw],n:1};e.raw=null;}}
function spawnMob(w,kind,x,z,dimension,y){const def=MOBS[kind];if(!def)return;let yy=y??(dimension==='nether'?42:w.terrain.column(Math.floor(x),Math.floor(z)).height+1);const getB=(X,Y,Z)=>get(w,dimension,X,Y,Z);while(yy<HEIGHT-3&&collides(getB,x,yy,z))yy++;if(yy>=HEIGHT-3)return;w.mobs.push({id:randomUUID(),kind,x,y:yy,z,yaw:Math.random()*Math.PI*2,hp:def.hp,dimension,vy:0,vx:0,vz:0,health:1,hunger:20,mode:'survival',ground:false,wander:Date.now()+2000});}
function tickMobs(w,dt){const now=Date.now(),players=[...online.values()].filter(a=>a.w===w&&a.p.health>0);for(const m of w.mobs){const def=MOBS[m.kind];let nearest=null,best=28;for(const a of players)if(a.p.dimension===m.dimension){const r=Math.hypot(a.p.x-m.x,a.p.z-m.z);if(r<best){best=r;nearest=a;}}if(!nearest)continue;
  const hostile=!def.passive&&(m.kind!=='piglin'||now<(m.angryUntil||0));let chase=hostile&&nearest.p.mode==='survival';
  if(chase)m.yaw=Math.atan2(nearest.p.x-m.x,-(nearest.p.z-m.z));else if(now>m.wander){m.yaw+=Math.random()*2-1;m.wander=now+2000+Math.random()*5000;}
  const getter=(x,y,z)=>get(w,m.dimension,x,y,z);physics(m,{forward:chase?best>(def.ranged?7:1.3):Math.sin(now/3000+m.x)>.3,jump:m.ground&&(solid(getter(Math.floor(m.x+Math.sin(m.yaw)),Math.floor(m.y),Math.floor(m.z-Math.cos(m.yaw)))))},dt*.45,getter);
  if(chase&&best<(def.ranged?14:1.7)&&Math.abs(nearest.p.y-m.y)<(def.ranged?8:2)&&now>(m.attack||0)){
   const o={x:m.x,y:m.y+1,z:m.z},v={x:nearest.p.x-o.x,y:nearest.p.y+1-o.y,z:nearest.p.z-o.z},l=Math.hypot(v.x,v.y,v.z),wall=raycast(getter,o,{x:v.x/l,y:v.y/l,z:v.z/l},l);if(!wall||wall.distance>=l-.4){m.attack=now+(def.ranged?2200:1200);if(m.kind==='creeper'){m.fuse??=now;if(now-m.fuse>1500){for(const a of players)if(a.p.dimension===m.dimension&&Math.hypot(a.p.x-m.x,a.p.y-m.y,a.p.z-m.z)<4)hurt(a,12);for(let dx=-2;dx<=2;dx++)for(let dy=-1;dy<=2;dy++)for(let dz=-2;dz<=2;dz++)if(Math.hypot(dx,dy,dz)<2.5){const x=Math.floor(m.x)+dx,y=Math.floor(m.y)+dy,z=Math.floor(m.z)+dz,id=get(w,m.dimension,x,y,z);if(id&&BLOCKS[id].hardness<5)set(w,m.dimension,x,y,z,0);}m.hp=0;}}else{hurt(nearest,def.damage);if(def.ranged){w.projectiles??=[];w.projectiles.push({id:randomUUID(),x:m.x,y:m.y+1,z:m.z,tx:nearest.p.x,ty:nearest.p.y+1,tz:nearest.p.z,kind:m.kind,time:now});}}}
  }else if(best>3)m.fuse=null;
  if(m.y<0)m.hp=0;
 }
 w.mobs=w.mobs.filter(m=>m.hp>0);w.projectiles=(w.projectiles||[]).filter(q=>now-q.time<600);
}
let ticks=0,lastTick=performance.now();
const timer=setInterval(()=>{try{const now=performance.now(),dt=Math.min(.05,(now-lastTick)/1000);lastTick=now;ticks++;
 for(const a of online.values()){
  if(Date.now()-a.lastSeen>20000){savePlayer(a);online.delete(a.user.id);continue;}
  const p=a.p,getter=(x,y,z)=>get(a.w,p.dimension,x,y,z);if(Date.now()-(a.lastInput||0)>350)a.input={};physics(p,a.input,dt,getter);
  if(ticks%20===0&&p.health>0&&p.mode==='survival'){
   const feet=getter(Math.floor(p.x),Math.floor(p.y+.1),Math.floor(p.z)),head=getter(Math.floor(p.x),Math.floor(p.y+1.6),Math.floor(p.z));
   p.hunger=Math.max(0,p.hunger-((a.input.forward||a.input.back||a.input.left||a.input.right)?a.input.sprint?.09:.025:.006));
   p.oxygen=head===B.WATER?Math.max(0,p.oxygen-1):20;if(!p.oxygen)hurt(a,2);if(feet===B.LAVA||head===B.LAVA)hurt(a,6);
   if(!p.hunger)hurt(a,1);else if(p.hunger>16&&p.health<20&&ticks%80===0){p.health++;p.hunger=Math.max(0,p.hunger-.3);}
   if(p.y<-5)p.health=0;
  }
  death(a);if(p.health>0){for(let i=a.w.drops.length-1;i>=0;i--){const q=a.w.drops[i];if(q.dimension===p.dimension&&Math.hypot(q.x-p.x,q.y-p.y,q.z-p.z)<1.8&&addItem(p.inventory,q.item,q.n,q.dur))a.w.drops.splice(i,1);}}
  const inPortal=getter(Math.floor(p.x),Math.floor(p.y+.5),Math.floor(p.z))===B.PORTAL;if(inPortal){a.portalSince??=Date.now();if(Date.now()-a.portalSince>1200)enterPortal(a);}else a.portalSince=null;
 }
 for(const w of worlds.values())if([...online.values()].some(a=>a.w===w)){
  w.time=(w.time+dt*20)%24000;tickMobs(w,dt);w.drops=w.drops.filter(q=>q.expires>Date.now());for(const e of w.blockEntities.values())finishFurnace(e);
  if(ticks%200===0&&w.mobs.length<64){for(const a of online.values())if(a.w===w){const ang=Math.random()*Math.PI*2,x=a.p.x+Math.sin(ang)*24,z=a.p.z+Math.cos(ang)*24,d=a.p.dimension,night=w.time>13000;const types=d==='nether'?['piglin','blaze','magma_cube','ghast']:night?['zombie','skeleton','spider','creeper']:['pig','cow','sheep','chicken'];if(d==='nether'||w.terrain.column(x,z).height>35)spawnMob(w,types[Math.floor(Math.random()*types.length)],x,z,d);}}
 }
 if(ticks%100===0)saveAll();if(ticks%1200===0){stmt('DELETE FROM sessions WHERE expires<?').run(Date.now());for(const [k,v] of limits)if(Date.now()-v.t>3600000)limits.delete(k);}
}catch(e){console.error('Simulation error:',e.message);}},50);
async function body(req){let n=0,parts=[];for await(const p of req){n+=p.length;if(n>16384)fail('Request too large.',413);parts.push(p);}try{return JSON.parse(Buffer.concat(parts).toString()||'{}');}catch{fail('Invalid JSON.');}}
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.txt':'text/plain; charset=utf-8','.svg':'image/svg+xml'};
function respond(res,status,obj){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(obj));}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','SAMEORIGIN');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; worker-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'; form-action 'self'");
 try{
  const url=new URL(req.url,publicOrigin),path=url.pathname,ip=clientIP(req);rate('http:'+ip,6000,60000);
  if(req.method==='POST'){
   if(req.headers.origin!==publicOrigin)fail('Request origin rejected.',403);
   if(!String(req.headers['content-type']).startsWith('application/json'))fail('JSON required.',415);
  }
  if(path==='/api/status')return respond(res,200,{ok:true,version:'0.1.2',ownerConfigured:!!ownerID(),whitelist:setting('whitelist')==='on'});
  if(path==='/api/me'){const u=session(req);return respond(res,200,{user:u?info(u):null});}
  if(path==='/api/register'&&req.method==='POST'){
   rate('register:'+ip,5,3600000);const c=await body(req);validateName(c.username);checkPassword(c.password);if(c.username.toLowerCase()==='jonah')fail('Jonah is reserved for the owner.',403);
   if(stmt('SELECT id FROM users WHERE username=? COLLATE NOCASE').get(c.username))fail('This username is unavailable.',409);
   const salt=randomBytes(16).toString('hex'),pw=await passwordHash(c.password,salt),id=randomUUID();try{stmt('INSERT INTO users(id,username,salt,password,created) VALUES(?,?,?,?,?)').run(id,c.username,salt,pw,Date.now());}catch{fail('This username is unavailable.',409);}const u=stmt('SELECT * FROM users WHERE id=?').get(id);return respond(res,201,{user:authenticate(u,res)});
  }
  if(path==='/api/login'&&req.method==='POST'){
   rate('login:'+ip,20,900000);const c=await body(req);validateName(c.username);if(typeof c.password!=='string'||Buffer.byteLength(c.password)>256)fail('Invalid username or password.',401);rate('login-user:'+c.username.toLowerCase(),12,900000);
   const u=stmt('SELECT * FROM users WHERE username=? COLLATE NOCASE').get(c.username),pw=await passwordHash(c.password,u?.salt||'b6b8e78f35ef7740ae293d19f28b8777'),expected=u?.password||'0'.repeat(128);if(!timingSafeEqual(Buffer.from(pw,'hex'),Buffer.from(expected,'hex'))||!u||u.banned)fail('Invalid username or password.',401);return respond(res,200,{user:authenticate(u,res)});
  }
  if(path==='/api/setup'&&req.method==='POST'){
   rate('setup:'+ip,5,900000);if(!setupToken||ownerID()||Date.now()>setupExpires||!remoteSetup&&!['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress))fail('Owner setup is unavailable.',403);
   const c=await body(req);if(typeof c.token!=='string'||c.token.length!==setupToken.length||!timingSafeEqual(Buffer.from(c.token),Buffer.from(setupToken)))fail('Invalid setup link.',403);checkPassword(c.password);const salt=randomBytes(16).toString('hex'),pw=await passwordHash(c.password,salt),id=randomUUID();transaction(()=>{if(ownerID())fail('Owner already configured.',409);stmt('INSERT INTO users(id,username,salt,password,allowed,created) VALUES(?,?,?,?,1,?)').run(id,'Jonah',salt,pw,Date.now());putSetting('owner_id',id);});return respond(res,201,{user:authenticate(stmt('SELECT * FROM users WHERE id=?').get(id),res)});
  }
  if(path==='/api/logout'&&req.method==='POST'){const u=session(req);if(u){const a=online.get(u.id);if(a&&a.session===u.session){savePlayer(a);online.delete(u.id);}stmt('DELETE FROM sessions WHERE token=?').run(u.session);}res.setHeader('Set-Cookie',cookie('',true));return respond(res,200,{ok:true});}
  if(path.startsWith('/api/')){
   const u=needUser(req);
   if(path==='/api/worlds'&&req.method==='GET')return respond(res,200,{worlds:stmt('SELECT id,name,seed,mode FROM worlds').all(),online:[...online.values()].map(a=>({name:a.user.username,world:a.w.id}))});
   if(path==='/api/worlds'&&req.method==='POST'){rate('worlds:'+u.id,3,3600000);const c=await body(req);if(typeof c.name!=='string'||c.name.length<1||c.name.length>48||typeof c.seed!=='string'||c.seed.length>128||!['survival','creative'].includes(c.mode))fail('Invalid world settings.');if(!isOwner(u)&&stmt('SELECT count(*) AS n FROM worlds WHERE creator=?').get(u.id).n>=2)fail('Two worlds per account.');if(stmt('SELECT count(*) AS n FROM worlds').get().n>=32)fail('Server world limit reached.');return respond(res,201,{id:createWorld(c.name,c.seed,c.mode,u.id)});}
   if(path==='/api/join'&&req.method==='POST'){
    const c=await body(req),w=world(c.world),old=online.get(u.id);if(old)savePlayer(old);let r=stmt('SELECT state FROM players WHERE user_id=? AND world_id=?').get(u.id,w.id);const p=r?JSON.parse(r.state):newPlayer(w.terrain,w.mode);const a={user:info(u),session:u.session,w,p,input:{},lastSeen:Date.now(),dead:p.health<=0};online.set(u.id,a);savePlayer(a);
    if(!w.mobs.length)for(let i=0;i<8;i++)spawnMob(w,['pig','cow','sheep','chicken'][i%4],p.x+5+Math.sin(i*2)*9,p.z+Math.cos(i*2)*9,'overworld');return respond(res,200,{world:{id:w.id,name:w.name,seed:w.seed,mode:w.mode},player:view(a),revision:w.revision});
   }
   if(path==='/api/input'&&req.method==='POST'){const a=active(u),c=await body(req);rate('input:'+u.id,50,1000);a.lastInput=Date.now();a.input=Object.fromEntries(['forward','back','left','right','jump','down','sprint'].map(k=>[k,c[k]===true]));if(Number.isFinite(c.yaw)&&Number.isFinite(c.pitch)){a.p.yaw=c.yaw%(Math.PI*2);a.p.pitch=Math.max(-1.55,Math.min(1.55,c.pitch));}return respond(res,200,{ok:true});}
   if(path==='/api/state'&&req.method==='GET'){const a=active(u),w=a.w,rev=Number(url.searchParams.get('since')||0);return respond(res,200,{player:view(a),players:[...online.values()].filter(q=>q.w===w).map(q=>({id:q.user.id,name:q.user.username,x:q.p.x,y:q.p.y,z:q.p.z,yaw:q.p.yaw,dimension:q.p.dimension,health:q.p.health,owner:isOwner(q.user)})),mobs:w.mobs.filter(m=>m.dimension===a.p.dimension&&Math.hypot(m.x-a.p.x,m.z-a.p.z)<160),drops:w.drops.filter(q=>q.dimension===a.p.dimension),projectiles:w.projectiles||[],time:w.time,weather:w.weather,revision:w.revision,changes:w.changes.filter(c=>c.r>rev),reload:rev<w.revision&&(!w.changes.length||rev<w.changes[0].r-1),chat:w.chat||[]});}
   if(path==='/api/chunk'&&req.method==='GET'){const a=active(u),cx=Number(url.searchParams.get('x')),cz=Number(url.searchParams.get('z')),dim=url.searchParams.get('d');rate('chunk:'+u.id,160,1000);if(!Number.isInteger(cx)||!Number.isInteger(cz)||!['nether','overworld'].includes(dim)||Math.abs(cx*16-a.p.x)>192||Math.abs(cz*16-a.p.z)>192||dim!==a.p.dimension)fail('Chunk out of range.');const edits=[];for(const [k,b] of a.w.edits){const [d,coords]=k.split(':'),[x,y,z]=coords.split(',').map(Number);if(d===dim&&Math.floor(x/16)===cx&&Math.floor(z/16)===cz)edits.push([x,y,z,b]);}return respond(res,200,{edits,revision:a.w.revision});}
   if(path==='/api/action'&&req.method==='POST'){rate('action:'+u.id,60,1000);const a=active(u),c=await body(req);let result=transaction(()=>action(a,c));return respond(res,200,{...result,player:view(a)});}
   if(path==='/api/leave'&&req.method==='POST'){const a=active(u);savePlayer(a);saveWorld(a.w);online.delete(u.id);return respond(res,200,{ok:true});}
   if(path==='/api/owner'&&req.method==='GET'){requireOwner(u);return respond(res,200,{users:stmt('SELECT id,username,banned,allowed,created FROM users').all(),backups:backupNames(),whitelist:setting('whitelist')==='on',ownerID:ownerID()});}
   if(path==='/api/owner'&&req.method==='POST'){
    requireOwner(u);const c=await body(req),a=active(u);
    if(c.op==='command')return respond(res,200,command(a,c.text));
    if(c.op==='backup'){
     saveAll();const w=a.w,id=`${new Date().toISOString().replaceAll(/[:.]/g,'-')}-${w.id}.json`,record={format:1,world:stmt('SELECT * FROM worlds WHERE id=?').get(w.id),edits:stmt('SELECT * FROM edits WHERE world_id=?').all(w.id),players:stmt('SELECT * FROM players WHERE world_id=?').all(w.id),entities:stmt('SELECT * FROM entities WHERE world_id=?').all(w.id)};stmt('INSERT INTO backups VALUES(?,?,?,?)').run(id,w.id,Date.now(),JSON.stringify(record));audit(u,'backup '+id);return respond(res,200,{backup:id});
    }
    if(c.op==='restore'){
     if(typeof c.backup!=='string'||!/^[a-zA-Z0-9T-]+\.json$/.test(c.backup)||!backupText(c.backup))fail('Choose a server backup.');const b=JSON.parse(backupText(c.backup));if(b.format!==1||b.world.id!==a.w.id)fail('Join the backup’s world before restoring.');
     transaction(()=>{const id=b.world.id;stmt('UPDATE worlds SET state=? WHERE id=?').run(b.world.state,id);for(const t of ['edits','players','entities'])stmt(`DELETE FROM ${t} WHERE world_id=?`).run(id);for(const e of b.edits)stmt('INSERT INTO edits VALUES(?,?,?,?,?,?)').run(e.world_id,e.dimension,e.x,e.y,e.z,e.block);for(const e of b.players)if(stmt('SELECT id FROM users WHERE id=?').get(e.user_id))stmt('INSERT INTO players VALUES(?,?,?)').run(e.user_id,e.world_id,e.state);for(const e of b.entities)stmt('INSERT INTO entities VALUES(?,?,?)').run(e.world_id,e.position,e.state);});for(const q of online.values())if(q.w.id===a.w.id)online.delete(q.user.id);worlds.delete(a.w.id);audit(u,'restore '+c.backup);return respond(res,200,{message:'Restored. Rejoin the world.'});
    }
    fail('Unknown owner action.');
   }
   if(path==='/api/backup'&&req.method==='GET'){requireOwner(u);const name=url.searchParams.get('name');if(!/^[a-zA-Z0-9T-]+\.json$/.test(name||'')||!backupText(name))fail('Backup missing.',404);res.writeHead(200,{'Content-Type':'application/json','Content-Disposition':`attachment; filename="${name}"`,'Cache-Control':'no-store'});return res.end(backupText(name));}
   fail('API route not found.',404);
  }
  if(req.method!=='GET'&&req.method!=='HEAD')fail('Method not allowed.',405);
  const name=path==='/setup'?'/setup.html':path==='/'?'/index.html':decodeURIComponent(path);const file=resolve(root,'public','.'+name);if(!file.startsWith(resolve(root,'public')+requireSep())||!existsSync(file)||!statSync(file).isFile())fail('File not found.',404);const bytes=readFileSync(file);let headers={'Content-Type':mime[extname(file)]||'application/octet-stream','Cache-Control':'no-cache'};const compress=String(req.headers['accept-encoding']).includes('gzip')&&bytes.length>1024;if(compress){headers['Content-Encoding']='gzip';headers.Vary='Accept-Encoding';}res.writeHead(200,headers);res.end(req.method==='HEAD'?undefined:compress?gzipSync(bytes):bytes);
 }catch(e){if(!res.headersSent)respond(res,e.status||500,{error:e.status?e.message:'Server error. Please try again.'});if(!e.status)console.error(e.stack);}
});
function requireSep(){return process.platform==='win32'?'\\':'/';}
server.requestTimeout=10000;server.headersTimeout=10000;server.maxHeadersCount=50;
server.listen(port,host,()=>{console.log(`JonahCraft ready: ${publicOrigin}`);console.log(`World storage: ${data}`);if(setupToken&&remoteSetup)console.log('Private HTTPS owner setup is enabled for 15 minutes. The setup secret is never printed.');else if(setupToken)console.log(`PRIVATE OWNER SETUP (expires in 15 minutes): ${publicOrigin}/setup#${setupToken}`);else if(!ownerID())console.log('Jonah is reserved. Stop this server and run node server.mjs --setup to create the owner privately.');});
function shutdown(){clearInterval(timer);saveAll();server.close(()=>{db.close();process.exit(0);});setTimeout(()=>process.exit(0),3000).unref();}
process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
