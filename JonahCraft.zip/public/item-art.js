// All sprites and the cube projection are original, painted on a 16-pixel grid.
export function paintItem(canvas,id,{atlas,ITEMS,B}){
 const item=ITEMS[id],q=canvas.getContext('2d');q.imageSmoothingEnabled=false;q.clearRect(0,0,32,32);if(!item)return;
 if(item.block===B.TORCH){q.fillStyle='#583c24';q.fillRect(13,9,6,21);q.fillStyle='#be9454';q.fillRect(13,11,3,18);q.fillStyle='#ee9821';q.fillRect(11,4,10,10);q.fillStyle='#ffe18a';q.fillRect(13,2,6,9);q.fillStyle='#fff3c2';q.fillRect(15,3,2,5);return;}
 if(item.block){
  const b=item.block,top=b===B.LOG?34:b===B.TABLE?36:b,side=b===B.GRASS?33:b===B.CHEST?37:b===B.FURNACE?35:b;
  const face=(tile,a,b,c,d,e,f,shade)=>{q.save();q.setTransform(a,b,c,d,e,f);q.drawImage(atlas,tile%8*16,Math.floor(tile/8)*16,16,16,0,0,16,16);if(shade){q.fillStyle='rgba(0,0,0,'+shade+')';q.fillRect(0,0,16,16);}q.restore();};
  face(top,.84,-.42,.84,.42,2,9,0);face(side,.84,.42,0,.94,2,9,.12);face(side,.84,-.42,0,.94,15.44,15.72,.28);return;
 }
 const c=document.createElement('canvas');c.width=c.height=16;const p=c.getContext('2d'),fill=(x,y,w,h,color)=>{p.fillStyle=color;p.fillRect(x,y,w,h);};
 const material=id.split('_')[0],colors=({wooden:['#4b321e','#986333','#c59a56'],stone:['#353d3b','#7d8781','#b5bcb2'],iron:['#434b4c','#b8c5c4','#edf5ec'],diamond:['#155b54','#35b9ab','#a0f4d3'],gold:['#73501b','#d7a934','#ffe892']})[material]||['#65452c','#ad8656','#e1c79a'];
 if(item.tool){
  for(let i=0;i<9;i++){fill(2+i,12-i,3,3,'#45301e');fill(2+i,12-i,1,2,'#b08a4e');}
  if(item.tool==='pickaxe'){fill(5,1,9,3,colors[0]);fill(9,3,6,5,colors[0]);fill(6,1,7,1,colors[2]);fill(7,2,7,2,colors[1]);fill(12,4,2,3,colors[1]);}
  if(item.tool==='sword'){for(let i=0;i<9;i++){fill(6+i,9-i,3,3,colors[0]);fill(7+i,9-i,1,2,colors[1]);fill(7+i,9-i,1,1,colors[2]);}fill(4,8,3,2,'#56472c');fill(6,10,3,2,'#b3a16e');}
  if(item.tool==='axe'){fill(7,1,7,7,colors[0]);fill(6,2,7,5,colors[1]);fill(6,2,6,1,colors[2]);fill(5,3,2,3,colors[1]);}
  if(item.tool==='shovel'){fill(10,1,5,6,colors[0]);fill(9,2,5,4,colors[1]);fill(10,2,3,1,colors[2]);}
 }else if(item.armor){
  const shapes={helmet:[[3,3,10,7],[2,5,12,5]],chestplate:[[4,3,8,10],[1,4,14,4]],leggings:[[3,2,10,5],[3,6,4,9],[9,6,4,9]],boots:[[3,7,4,7],[9,7,4,7],[2,12,5,3],[9,12,5,3]]};
  for(const [x,y,w,h]of shapes[item.armor]){fill(x,y,w,h,colors[0]);fill(x+1,y+1,w-2,h-2,colors[1]);fill(x+1,y+1,w-2,1,colors[2]);}if(item.armor==='helmet')p.clearRect(5,6,6,5);if(item.armor==='chestplate')p.clearRect(6,2,4,4);
 }else if(id==='stick'||id==='blaze_rod'||id==='bone'){for(let i=0;i<11;i++){fill(2+i,12-i,2,3,id==='bone'?'#a5a18d':id==='blaze_rod'?'#a45a16':'#67442a');fill(2+i,12-i,1,2,id==='bone'?'#ede5cc':id==='blaze_rod'?'#ffe481':'#b28b52');}}
 else if(id.includes('ingot')){const gold=id==='gold_ingot';fill(2,7,12,6,gold?'#91681e':'#5a6768');fill(3,6,10,6,gold?'#deb532':'#aab7b9');fill(4,5,8,3,gold?'#ffde6c':'#e0ebeb');fill(3,11,10,1,gold?'#be8a23':'#87999d');}
 else if(id==='apple'){fill(7,1,2,4,'#6c4526');fill(9,2,4,2,'#6a9438');fill(3,5,10,8,'#792a23');fill(2,6,12,5,'#ad3329');fill(4,5,3,2,'#ee7660');fill(4,12,8,2,'#9e2e25');}
 else if(item.food){const cooked=id.startsWith('cooked');fill(4,3,8,10,cooked?'#6f3922':'#96514a');fill(2,6,12,5,cooked?'#a36532':'#d78b81');fill(5,4,6,3,cooked?'#ca8f53':'#f0b5a0');fill(8,12,5,2,'#e3d9b9');}
 else if(id==='diamond'||id==='emerald'||id==='lapis'||id==='quartz'||id==='coal'){const [edge,base,shine]=({diamond:['#1d736a','#48cdb8','#c2fff0'],emerald:['#1d6934','#43bc61','#b1ed91'],lapis:['#1c3570','#3f65ba','#90b2e7'],quartz:['#92837a','#d5c9b4','#fff4dd'],coal:['#141719','#30373b','#5b6265']})[id];fill(5,2,6,12,edge);fill(3,5,10,6,edge);fill(5,4,6,8,base);fill(4,5,2,4,base);fill(6,3,4,2,shine);fill(5,5,2,3,shine);}
 else if(id==='feather'||id==='string'){for(let i=0;i<10;i++){fill(3+i,12-i,2,2,'#c9c8b4');if(id==='feather')fill(2+i,10-i,3,3,'#f0ead7');}}
 else{fill(5,3,6,11,'#544b42');fill(3,5,10,7,id==='redstone'?'#b62621':id==='gunpowder'?'#777b78':id==='nether_key'?'#593b78':'#b6a081');fill(5,4,5,3,id==='redstone'?'#e94b35':id==='nether_key'?'#c499e0':'#d8c9a3');}
 q.drawImage(c,0,0,16,16,0,0,32,32);
}
