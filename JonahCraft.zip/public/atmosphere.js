import * as THREE from './vendor/three.module.js';
import {hash} from './shared/game.js';

// Original sky art; one sky mesh, one stars draw call, and merged cloud geometry.
export function createAtmosphere(scene){
 const uniforms={zenith:{value:new THREE.Color()},horizon:{value:new THREE.Color()},under:{value:new THREE.Color()}};
 const dome=new THREE.Mesh(new THREE.SphereGeometry(210,24,12),new THREE.ShaderMaterial({
  uniforms,side:THREE.BackSide,depthWrite:false,
  vertexShader:'varying vec3 ray; void main(){ray=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
  fragmentShader:'varying vec3 ray;uniform vec3 zenith,horizon,under;void main(){float h=normalize(ray).y;vec3 c=mix(horizon,zenith,pow(clamp(h,0.0,1.0),0.45));c=mix(c,under,smoothstep(-0.03,-0.55,h));gl_FragColor=vec4(c,1.0);\n#include <tonemapping_fragment>\n#include <colorspace_fragment>}',
 }));dome.renderOrder=-100;scene.add(dome);
 const starPositions=[];for(let i=0;i<500;i++){const y=hash(i,18,7)*.97+.02,a=hash(i,21,9)*Math.PI*2,r=Math.sqrt(1-y*y)*180;starPositions.push(Math.cos(a)*r,y*180,Math.sin(a)*r);}
 const starGeometry=new THREE.BufferGeometry();starGeometry.setAttribute('position',new THREE.Float32BufferAttribute(starPositions,3));
 const stars=new THREE.Points(starGeometry,new THREE.PointsMaterial({color:0xe5efff,size:.55,sizeAttenuation:true,transparent:true,depthWrite:false,fog:false}));stars.renderOrder=-90;scene.add(stars);
 function celestial(size,moon){
  const c=document.createElement('canvas');c.width=c.height=16;const q=c.getContext('2d');q.fillStyle=moon?'#c3d0d7':'#fff2c5';q.fillRect(0,0,16,16);q.fillStyle=moon?'#e9f1ee':'#fffbdc';q.fillRect(2,2,12,12);
  if(moon){q.fillStyle='#b4c2ca';for(const [x,y,w,h]of [[3,4,3,3],[9,8,4,3],[5,11,2,2],[11,2,2,3]])q.fillRect(x,y,w,h);}else{q.fillStyle='#fffef2';q.fillRect(4,4,8,8);}
  const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;t.colorSpace=THREE.SRGBColorSpace;
  const mesh=new THREE.Mesh(new THREE.PlaneGeometry(size,size),new THREE.MeshBasicMaterial({map:t,depthWrite:false,fog:false}));scene.add(mesh);return mesh;
 }
 const sun=celestial(12,false),moon=celestial(8,true);
 const cloudPositions=[],cloudNormals=[];
 const cube=new THREE.BoxGeometry(1,1,1).toNonIndexed();
 for(let z=-5;z<=5;z++)for(let x=-5;x<=5;x++)if(hash(x,8,z,381)>.53){const w=10+Math.floor(hash(x,1,z)*3)*8,d=8+Math.floor(hash(x,2,z)*3)*8;const g=cube.clone();g.scale(w,2.8,d);g.translate(x*34,0,z*34);cloudPositions.push(...g.attributes.position.array);cloudNormals.push(...g.attributes.normal.array);g.dispose();}
 cube.dispose();const cg=new THREE.BufferGeometry();cg.setAttribute('position',new THREE.Float32BufferAttribute(cloudPositions,3));cg.setAttribute('normal',new THREE.Float32BufferAttribute(cloudNormals,3));
 const clouds=new THREE.Mesh(cg,new THREE.MeshLambertMaterial({color:0xffffff,transparent:true,opacity:.9,depthWrite:false}));scene.add(clouds);
 const dayTop=new THREE.Color('#659cdb'),dayHorizon=new THREE.Color('#c1dcf2'),nightTop=new THREE.Color('#070c20'),nightHorizon=new THREE.Color('#192e49'),duskColor=new THREE.Color('#e4a17e'),fogColor=new THREE.Color();
 return {update({position,time,ticks,nether,underwater,rain,distance}){
  const angle=ticks/24000*Math.PI*2,day=nether?.18:THREE.MathUtils.smoothstep(Math.sin(angle),-.18,.5),dusk=nether?0:Math.max(0,1-Math.abs(Math.sin(angle))*5);
  dome.position.copy(position);stars.position.copy(position);dome.visible=!nether;stars.visible=!nether&&!underwater;stars.material.opacity=(1-day)*.8*(rain?.2:1);
  uniforms.zenith.value.copy(nightTop).lerp(dayTop,day);uniforms.horizon.value.copy(nightHorizon).lerp(dayHorizon,day).lerp(duskColor,dusk*.48);uniforms.under.value.copy(uniforms.horizon.value).multiplyScalar(.75);
  if(rain){uniforms.zenith.value.lerp(new THREE.Color('#74828c'),.55);uniforms.horizon.value.lerp(new THREE.Color('#a2abb1'),.6);}
  fogColor.copy(uniforms.horizon.value);if(nether)fogColor.set('#452225');if(underwater)fogColor.set('#244c86');
  scene.background=fogColor;scene.fog.color.copy(fogColor);scene.fog.near=underwater?1:distance*.5;scene.fog.far=underwater?19:distance*.98;
  dome.visible=!nether&&!underwater;clouds.visible=!nether&&!underwater;clouds.position.set(Math.floor(position.x/128)*128+(time*.7%128)-64,86,Math.floor(position.z/128)*128);clouds.material.color.setRGB(.38+day*.62,.42+day*.58,.54+day*.46);
  for(const [mesh,sign]of [[sun,1],[moon,-1]]){mesh.visible=!nether&&!underwater;mesh.position.set(position.x+Math.cos(angle)*140*sign,position.y+Math.sin(angle)*140*sign,position.z-45*sign);mesh.lookAt(position);}
  return Math.max(.08,day)*(rain?.74:1);
 }};
}
