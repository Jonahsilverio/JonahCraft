import * as THREE from './vendor/three.module.js';
// All creature shadows share one draw call and one original 32-pixel texture.
export function createContactShadows(scene,getVoxel,solid){
 const c=document.createElement('canvas');c.width=c.height=32;const q=c.getContext('2d'),gradient=q.createRadialGradient(16,16,2,16,16,15);gradient.addColorStop(0,'#0009');gradient.addColorStop(.5,'#0006');gradient.addColorStop(1,'#0000');q.fillStyle=gradient;q.fillRect(0,0,32,32);
 const tex=new THREE.CanvasTexture(c);tex.magFilter=THREE.NearestFilter;const geometry=new THREE.PlaneGeometry(1,1);geometry.rotateX(-Math.PI/2);
 const mesh=new THREE.InstancedMesh(geometry,new THREE.MeshBasicMaterial({map:tex,transparent:true,depthWrite:false,opacity:.5,polygonOffset:true,polygonOffsetFactor:-1}),96);mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);mesh.frustumCulled=false;mesh.count=0;scene.add(mesh);const dummy=new THREE.Object3D();
 return {update(entities,visible){let count=0;mesh.visible=visible;if(!visible)return;for(const [id,g]of entities){if(count>=96||id.startsWith('drop:')||id.startsWith('proj:')||!g.visible)continue;const {x,y,z}=g.position;let floor=null;for(let depth=0;depth<6;depth++){const Y=Math.floor(y-.02)-depth;if(solid(getVoxel(Math.floor(x),Y,Math.floor(z)))){floor=Y+1;break;}}if(floor===null||floor>y+.2)continue;const size=Math.max(.15,1-(y-floor)/6);dummy.position.set(x,floor+.008,z);dummy.scale.set(size*.9,1,size*.9);dummy.updateMatrix();mesh.setMatrixAt(count++,dummy.matrix);}mesh.count=count;mesh.instanceMatrix.needsUpdate=true;}};
}
