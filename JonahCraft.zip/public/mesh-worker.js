import {Terrain,B,BLOCKS,HEIGHT,index,local,solid,hash} from './shared/game.js';
import {ChunkEdits} from './shared/chunk-edits.js';
let terrain,dimension='overworld',chunks=new Map();const edits=new ChunkEdits(),tickets=new Map();
const faces=[
 {n:[1,0,0],v:[[1,0,1],[1,0,0],[1,1,1],[1,1,0]],s:.78},
 {n:[-1,0,0],v:[[0,0,0],[0,0,1],[0,1,0],[0,1,1]],s:.68},
 {n:[0,1,0],v:[[0,1,1],[1,1,1],[0,1,0],[1,1,0]],s:1},
 {n:[0,-1,0],v:[[0,0,0],[1,0,0],[0,0,1],[1,0,1]],s:.52},
 {n:[0,0,1],v:[[0,0,1],[1,0,1],[0,1,1],[1,1,1]],s:.83},
 {n:[0,0,-1],v:[[1,0,0],[0,0,0],[1,1,0],[0,1,0]],s:.72}
];
function voxel(x,y,z){if(y<0)return B.BEDROCK;if(y>=HEIGHT)return 0;const a=chunks.get(Math.floor(x/16)+','+Math.floor(z/16));return a?a[index(local(x),y,local(z))]:0;}
function make(cx,cz){const array=chunks.get(cx+','+cz);if(!array)return;const opaque={p:[],n:[],u:[],c:[],i:[]},transparent={p:[],n:[],u:[],c:[],i:[]};
 const S=18,light=new Uint8Array(S*S*HEIGHT),sky=new Uint8Array(S*S*HEIGHT),q=[];const ix=(x,y,z)=>x+S*(z+S*y),read=(x,y,z)=>voxel(cx*16+x-1,y,cz*16+z-1);
 for(let z=0;z<S;z++)for(let x=0;x<S;x++){
  let sunlight=dimension==='nether'?2:15;
  for(let y=HEIGHT-1;y>=0;y--){const b=read(x,y,z),at=ix(x,y,z);if(solid(b)&&b!==B.LEAVES&&b!==B.GLASS)sunlight=0;else if(b===B.LEAVES||b===B.WATER)sunlight=Math.max(0,sunlight-1);sky[at]=sunlight;const emission=BLOCKS[b]?.light||0;if(emission){light[at]=emission;q.push(at);}}
 }
 const neighbors=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
 function spread(field,queue){for(let i=0;i<queue.length;i++){const at=queue[i],v=field[at]-1;if(v<1)continue;const y=Math.floor(at/(S*S)),z=Math.floor((at-y*S*S)/S),x=at%S;for(const [dx,dy,dz]of neighbors){const X=x+dx,Y=y+dy,Z=z+dz;if(X<0||X>=S||Z<0||Z>=S||Y<0||Y>=HEIGHT)continue;const p=ix(X,Y,Z);if(field[p]>=v)continue;const b=read(X,Y,Z);if(solid(b)&&!BLOCKS[b]?.transparent)continue;field[p]=v;queue.push(p);}}}
 spread(light,q);
 // Daylight wraps under tree canopies and into cave mouths instead of turning
 // every covered column black. Seed only boundaries that can gain light.
 const skyQueue=[];if(dimension!=='nether')for(let y=1;y<HEIGHT;y++)for(let z=1;z<S-1;z++)for(let x=1;x<S-1;x++){const at=ix(x,y,z),v=sky[at];if(v>1&&neighbors.some(([dx,dy,dz])=>y+dy>=0&&y+dy<HEIGHT&&sky[ix(x+dx,y+dy,z+dz)]<v-1))skyQueue.push(at);}spread(sky,skyQueue);
 for(let y=0;y<HEIGHT;y++)for(let z=0;z<16;z++)for(let x=0;x<16;x++){
  const b=array[index(x,y,z)];if(!b)continue;const out=[B.WATER,B.PORTAL,B.GLASS].includes(b)?transparent:opaque;
  for(const f of faces){const [dx,dy,dz]=f.n,neighbor=voxel(cx*16+x+dx,y+dy,cz*16+z+dz);
   if(neighbor===b||neighbor&&solid(neighbor)&&!BLOCKS[neighbor].transparent)continue;if(b===B.TORCH&&dy===-1)continue;
   const at=ix(Math.max(0,Math.min(17,x+dx+1)),Math.max(0,Math.min(HEIGHT-1,y+dy)),Math.max(0,Math.min(17,z+dz+1))),sun=(sky[at]||0)/15,em=Math.max(light[at]||0,BLOCKS[b].light||0)/15;
   // Vertex colour encodes sky in red and emitted light in green for day/night shading.
   let tile=b;if(b===B.GRASS)tile=dy===1?B.GRASS:dy===-1?B.DIRT:33;if(b===B.LOG&&dy)tile=34;if(b===B.FURNACE&&dz===-1)tile=35;if(b===B.TABLE&&dy===1)tile=36;if(b===B.CHEST&&dz===-1)tile=37;
   const tx=tile%8,ty=Math.floor(tile/8),base=out.p.length/3;
   f.v.forEach((v,i)=>{let [vx,vy,vz]=v;if(b===B.TORCH){vx=.43+vx*.14;vz=.43+vz*.14;vy*=.72;}if(b===B.WATER)vy*=.88;
    const tangents=[0,1,2].filter(a=>f.n[a]===0),corner=[vx,vy,vz],origin=[cx*16+x+dx,y+dy,cz*16+z+dz];
    const occupied=offset=>{const b=voxel(origin[0]+offset[0],origin[1]+offset[1],origin[2]+offset[2]);return solid(b)&&!BLOCKS[b]?.transparent?1:0;};
    const offsetA=[0,0,0],offsetB=[0,0,0];offsetA[tangents[0]]=corner[tangents[0]]<.5?-1:1;offsetB[tangents[1]]=corner[tangents[1]]<.5?-1:1;
    const sideA=occupied(offsetA),sideB=occupied(offsetB),occlusion=sideA&&sideB?0:3-sideA-sideB-occupied(offsetA.map((v,i)=>v+offsetB[i])),ambient=.58+occlusion*.14;
    out.p.push(cx*16+x+vx,y+vy,cz*16+z+vz);out.n.push(...f.n);const uv=[[0,0],[1,0],[0,1],[1,1]][i];out.u.push((tx+.02+uv[0]*.96)/8,1-(ty+.98-uv[1]*.96)/8);out.c.push(Math.max(.08,sun)*f.s*ambient,em*f.s,f.s);
   });
   // Choose the less visible diagonal through smoothly shaded block corners.
   if(out.c[base*3]+out.c[(base+3)*3]>out.c[(base+1)*3]+out.c[(base+2)*3])out.i.push(base,base+1,base+3,base,base+3,base+2);
   else out.i.push(base,base+1,base+2,base+2,base+1,base+3);
  }
  // Original grass and wildflower art adds depth without modifying saved blocks.
  // It only grows on exposed grass and disappears when the space is built on.
  if(dimension==='overworld'&&b===B.GRASS&&!voxel(cx*16+x,y+1,cz*16+z)&&hash(cx*16+x,0,cz*16+z,terrain.seed+177)>.74){
   const r=hash(cx*16+x,1,cz*16+z,terrain.seed+178),tile=r>.97?40:r>.94?39:38,tx=tile%8,ty=Math.floor(tile/8),h=tile===38?.65:.55;
   const px=x+.2+hash(cx*16+x,2,cz*16+z,terrain.seed)*.6,pz=z+.2+hash(cx*16+x,3,cz*16+z,terrain.seed)*.6,plantSample=ix(x+1,Math.min(HEIGHT-1,y+1),z+1),plantSky=Math.max(.08,sky[plantSample]/15)*.9,plantEmission=light[plantSample]/15;
   for(const flip of [-1,1]){const base=opaque.p.length/3;for(const [a,v]of [[0,0],[1,0],[0,1],[1,1]]){const ox=(a-.5)*.7;opaque.p.push(cx*16+px+ox,y+1+v*h,cz*16+pz+ox*flip);opaque.n.push(0,1,0);opaque.u.push((tx+.02+a*.96)/8,1-(ty+.98-v*.96)/8);opaque.c.push(plantSky,plantEmission,1);}opaque.i.push(base,base+1,base+2,base+2,base+1,base+3,base+2,base+1,base,base+3,base+1,base+2);}
  }
 }
 function typed(o){return {p:new Float32Array(o.p),n:new Float32Array(o.n),u:new Float32Array(o.u),c:new Float32Array(o.c),i:new Uint32Array(o.i)};}
 const o=typed(opaque),t=typed(transparent),voxels=array.slice();postMessage({type:'mesh',cx,cz,dimension,ticket:tickets.get(cx+','+cz),revision:edits.revision(cx,cz),opaque:o,transparent:t,voxels},[voxels.buffer,...Object.values(o).map(a=>a.buffer),...Object.values(t).map(a=>a.buffer)]);
}
self.onmessage=e=>{const m=e.data;
 if(m.type==='init'){terrain=new Terrain(m.seed);dimension=m.dimension;chunks.clear();edits.clear();tickets.clear();}
 if(m.type==='generate'){const a=terrain.generate(m.cx,m.cz,dimension);for(const c of edits.snapshot(m.cx,m.cz,m.edits,m.revision??0))a[index(local(c.x),c.y,local(c.z))]=c.b;const key=m.cx+','+m.cz;chunks.set(key,a);tickets.set(key,m.ticket);make(m.cx,m.cz);for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1]])make(m.cx+dx,m.cz+dz);}
 if(m.type==='edits'){const todo=new Set();for(const c of m.changes)if(c.d===dimension&&edits.remember(c)){const cx=Math.floor(c.x/16),cz=Math.floor(c.z/16),a=chunks.get(cx+','+cz);if(a)a[index(local(c.x),c.y,local(c.z))]=c.b;for(const [dx,dz]of [[0,0],[1,0],[-1,0],[0,1],[0,-1]])todo.add((cx+dx)+','+(cz+dz));}for(const k of todo){const [cx,cz]=k.split(',').map(Number);make(cx,cz);}}
 if(m.type==='unload'){chunks.delete(m.key);tickets.delete(m.key);const [cx,cz]=m.key.split(',').map(Number);edits.forget(cx,cz);}
};
