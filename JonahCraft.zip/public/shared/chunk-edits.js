// A chunk snapshot may arrive after newer live edits. Retain the newer edits
// until a snapshot at least as recent includes them. Shared by client and worker.
export class ChunkEdits{
 constructor(){this.chunks=new Map();}
 key(cx,cz){return cx+','+cz;}
 state(cx,cz){const key=this.key(cx,cz);if(!this.chunks.has(key))this.chunks.set(key,{base:-1,latest:0,edits:new Map()});return this.chunks.get(key);}
 remember(change){const s=this.state(Math.floor(change.x/16),Math.floor(change.z/16)),key=change.x+','+change.y+','+change.z,r=change.r??0;if(r<s.base||r<(s.edits.get(key)?.r??-1))return false;s.edits.set(key,{...change,r});s.latest=Math.max(s.latest,r);return true;}
 snapshot(cx,cz,edits,revision=0){const s=this.state(cx,cz);if(revision>=s.base){const newer=[...s.edits.values()].filter(c=>c.r>revision);s.edits.clear();for(const [x,y,z,b]of edits)s.edits.set(x+','+y+','+z,{x,y,z,b,r:revision});for(const c of newer)s.edits.set(c.x+','+c.y+','+c.z,c);s.base=revision;s.latest=Math.max(s.latest,revision);}return [...s.edits.values()];}
 revision(cx,cz){return this.chunks.get(this.key(cx,cz))?.latest??0;}
 values(cx,cz){return this.chunks.get(this.key(cx,cz))?.edits.values()??[];}
 forget(cx,cz){this.chunks.delete(this.key(cx,cz));}
 clear(){this.chunks.clear();}
}
