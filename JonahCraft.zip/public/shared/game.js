// Original JonahCraft simulation and terrain. Coordinates use one-metre cubes.
export const VERSION = '0.4.0', CHUNK = 16, HEIGHT = 96, SEA = 34;
const block = (name,color,opts={}) => ({name,color,solid:true,hardness:1,...opts});
export const BLOCKS = [
 block('Air','#000000',{solid:false,hardness:0}),
 block('Grass','#698f3d',{hardness:.6}), block('Dirt','#866044',{hardness:.5}),
 block('Stone','#818480',{hardness:2,tier:1,drop:'cobblestone'}),
 block('Sand','#d8c38b',{hardness:.5}), block('Water','#477fac',{solid:false,hardness:999,transparent:true}),
 block('Oak log','#715336',{hardness:1.5}), block('Leaves','#477239',{hardness:.3,transparent:true}),
 block('Planks','#b68a52'), block('Bedrock','#323538',{hardness:999}),
 block('Coal ore','#717674',{tier:1,hardness:2,drop:'coal'}),
 block('Iron ore','#999085',{tier:2,hardness:2,drop:'raw_iron'}),
 block('Gold ore','#ab9c64',{tier:3,hardness:2.5,drop:'raw_gold'}),
 block('Redstone ore','#9c4d4b',{tier:3,hardness:2.5,drop:'redstone'}),
 block('Lapis ore','#5264a4',{tier:2,hardness:2.5,drop:'lapis'}),
 block('Diamond ore','#63b2b7',{tier:3,hardness:3,drop:'diamond'}),
 block('Emerald ore','#51a878',{tier:3,hardness:3,drop:'emerald'}),
 block('Lava','#ec6a1f',{solid:false,hardness:999,light:15}),
 block('Cobblestone','#777b77',{tier:1,hardness:2}),
 block('Crafting table','#a87944',{hardness:1.5}), block('Furnace','#646968',{tier:1,hardness:2}),
 block('Chest','#ae783a',{hardness:1.5}), block('Torch','#efb347',{solid:false,hardness:.1,light:14,transparent:true}),
 block('Obsidian','#30273f',{tier:4,hardness:8}),
 block('Portal','#8c45ba',{solid:false,hardness:999,light:12,transparent:true}),
 block('Netherrack','#81493f',{tier:1,hardness:.7}),
 block('Soul sand','#635346',{hardness:.7}), block('Quartz ore','#b29a8f',{tier:1,hardness:2,drop:'quartz'}),
 block('Glowstone','#bd9959',{hardness:.5,light:15}),
 block('Nether bricks','#493032',{tier:1,hardness:2}), block('Glass','#b2d7d8',{hardness:.3,transparent:true}),
 block('Snow','#e4e9e6',{hardness:.3}), block('Wool','#ded8c8',{hardness:.6})
];
export const B = {AIR:0,GRASS:1,DIRT:2,STONE:3,SAND:4,WATER:5,LOG:6,LEAVES:7,PLANKS:8,BEDROCK:9,COAL:10,IRON:11,GOLD:12,REDSTONE:13,LAPIS:14,DIAMOND:15,EMERALD:16,LAVA:17,COBBLE:18,TABLE:19,FURNACE:20,CHEST:21,TORCH:22,OBSIDIAN:23,PORTAL:24,NETHERRACK:25,SOUL:26,QUARTZ:27,GLOWSTONE:28,BRICKS:29,GLASS:30,SNOW:31,WOOL:32};
export const slug = s=>s.toLowerCase().replaceAll(' ','_');
export const ITEMS = Object.fromEntries(BLOCKS.slice(1).map((v,i)=>[slug(v.name),{name:v.name,block:i+1,color:v.color}]));
Object.assign(ITEMS, {coal:{name:'Coal'},raw_iron:{name:'Raw iron'},iron_ingot:{name:'Iron ingot'},raw_gold:{name:'Raw gold'},gold_ingot:{name:'Gold ingot'},diamond:{name:'Diamond'},emerald:{name:'Emerald'},redstone:{name:'Redstone'},lapis:{name:'Lapis'},quartz:{name:'Quartz'},stick:{name:'Stick'},apple:{name:'Apple',food:4},raw_pork:{name:'Raw pork',food:2},raw_beef:{name:'Raw beef',food:2},raw_chicken:{name:'Raw chicken',food:1},cooked_pork:{name:'Cooked pork',food:8},cooked_beef:{name:'Cooked beef',food:8},cooked_chicken:{name:'Cooked chicken',food:6},feather:{name:'Feather'},leather:{name:'Leather'},bone:{name:'Bone'},string:{name:'String'},gunpowder:{name:'Gunpowder'},rotten_flesh:{name:'Rotten flesh',food:1},blaze_rod:{name:'Blaze rod'},magma_cream:{name:'Magma cream'},flint_and_steel:{name:'Flint and steel'},nether_key:{name:'Portal core'}});
for(const [material,tier,speed,durability] of [['wooden',1,2,60],['stone',2,4,132],['iron',3,6,251],['diamond',4,9,1562]]){
 for(const kind of ['pickaxe','axe','shovel','sword']) ITEMS[material+'_'+kind]={name:material[0].toUpperCase()+material.slice(1)+' '+kind,tier,speed,durability,tool:kind,damage:kind==='sword'?2+tier*2:1+tier};
}
for(const [material,defense] of [['leather',1],['iron',2],['diamond',3]]) for(const [slot,mult] of [['helmet',1],['chestplate',2],['leggings',1.5],['boots',1]]) ITEMS[material+'_'+slot]={name:material+' '+slot,armor:slot,defense:mult*defense};
export const RECIPES = [
 {out:'planks',n:4,in:{oak_log:1}}, {out:'stick',n:4,in:{planks:2}},
 {out:'crafting_table',n:1,in:{planks:4}}, {out:'torch',n:4,in:{coal:1,stick:1}},
 {out:'furnace',n:1,in:{cobblestone:8},table:true}, {out:'chest',n:1,in:{planks:8},table:true},
 {out:'flint_and_steel',n:1,in:{iron_ingot:1,coal:1}}, {out:'nether_key',n:1,in:{obsidian:10,iron_ingot:1},table:true},
 ...['wooden','stone','iron','diamond'].flatMap(m=>['pickaxe','axe','shovel','sword'].map(k=>({out:m+'_'+k,n:1,in:{[({wooden:'planks',stone:'cobblestone',iron:'iron_ingot',diamond:'diamond'})[m]]:k==='shovel'?1:k==='sword'?2:3,stick:k==='sword'?1:2},table:true}))),
 ...['leather','iron','diamond'].flatMap(m=>['helmet','chestplate','leggings','boots'].map((k,i)=>({out:m+'_'+k,n:1,in:{[m==='iron'?'iron_ingot':m]:[5,8,7,4][i]},table:true})))
];
export const SMELT = {raw_iron:'iron_ingot',raw_gold:'gold_ingot',sand:'glass',cobblestone:'stone',raw_pork:'cooked_pork',raw_beef:'cooked_beef',raw_chicken:'cooked_chicken'};
export const MOBS = {
 pig:{color:'#d39c91',hp:10,drop:'raw_pork',passive:true},cow:{color:'#695246',hp:10,drop:'raw_beef',passive:true},sheep:{color:'#d9d4bd',hp:8,drop:'wool',passive:true},chicken:{color:'#e9e3cb',hp:4,drop:'raw_chicken',passive:true},
 zombie:{color:'#557c46',hp:20,drop:'rotten_flesh',damage:3},skeleton:{color:'#c5c3b3',hp:20,drop:'bone',damage:3,ranged:true},spider:{color:'#493a35',hp:16,drop:'string',damage:2},creeper:{color:'#65944e',hp:20,drop:'gunpowder',damage:12},
 piglin:{color:'#ba8d7f',hp:20,drop:'gold_ingot',damage:4,nether:true},blaze:{color:'#dca833',hp:20,drop:'blaze_rod',damage:4,ranged:true,nether:true},magma_cube:{color:'#793626',hp:12,drop:'magma_cream',damage:3,nether:true},ghast:{color:'#dacfc8',hp:10,drop:'gunpowder',damage:5,ranged:true,nether:true}
};
export function seedNumber(text){let a=2166136261;for(const c of String(text))a=Math.imul(a^c.charCodeAt(0),16777619);return a>>>0;}
export function hash(x,y,z,s=0){let n=Math.imul(x|0,374761393)^Math.imul(y|0,668265263)^Math.imul(z|0,2147483647)^s;n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967295;}
const smooth=t=>t*t*(3-2*t),mix=(a,b,t)=>a+(b-a)*t;
export function noise(x,y,z,s){let X=Math.floor(x),Y=Math.floor(y),Z=Math.floor(z),a=smooth(x-X),b=smooth(y-Y),c=smooth(z-Z);return mix(mix(mix(hash(X,Y,Z,s),hash(X+1,Y,Z,s),a),mix(hash(X,Y+1,Z,s),hash(X+1,Y+1,Z,s),a),b),mix(mix(hash(X,Y,Z+1,s),hash(X+1,Y,Z+1,s),a),mix(hash(X,Y+1,Z+1,s),hash(X+1,Y+1,Z+1,s),a),b),c);}
export const index=(x,y,z)=>x+16*(z+16*y);
export const chunkKey=(x,z)=>Math.floor(x/16)+','+Math.floor(z/16);
export const local=n=>((n%16)+16)%16;
export class Terrain {
 constructor(seed){this.seed=seedNumber(seed);}
 column(x,z){const s=this.seed,n=(a,b,o)=>noise(x/a,0,z/a,s+o)*b;
  const continental=n(220,1,1), mountain=Math.max(0,n(90,1,5)-.53)*65;
  const river=Math.abs(n(135,1,8)-.5), desert=n(190,1,4)>.58;
  let height=Math.floor(22+continental*32+n(35,6,2)+mountain);
  if(river<.025)height=Math.min(height,29+Math.floor(river*130));
  return {height,biome:height<SEA-1?'ocean':river<.035?'river':height>61?'mountains':desert?'desert':n(75,1,7)>.46?'forest':'plains'};
 }
 generate(cx,cz,dimension='overworld'){
  const out=new Uint8Array(16*16*HEIGHT),s=this.seed;
  for(let z=0;z<16;z++)for(let x=0;x<16;x++){
   const wx=cx*16+x,wz=cz*16+z,{height:h,biome}=this.column(wx,wz);
   for(let y=0;y<HEIGHT;y++){
    let b=0;
    if(dimension==='nether'){
     const floor=17+Math.floor(noise(wx/30,0,wz/30,s+92)*18),ceiling=69+Math.floor(noise(wx/35,0,wz/35,s+94)*16);
     if(y===0||y===HEIGHT-1)b=B.BEDROCK;
     else if(y<floor||y>ceiling||noise(wx/22,y/18,wz/22,s+90)>.67)b=B.NETHERRACK;
     else if(y<22)b=B.LAVA;
     if(b===B.NETHERRACK){let r=hash(wx,y,wz,s+95);if(r>.975)b=B.QUARTZ;else if(y===floor-1&&r>.4)b=B.SOUL;else if(y>65&&r>.988)b=B.GLOWSTONE;}
     const fx=local(wx%160),fz=local(wz%160);
     // Repeating but seed-offset fortress bridges and piers, independently of chunks.
     const ax=((wx+(s%73))%160+160)%160,az=((wz+((s>>>8)%71))%160+160)%160;
     if((ax<6&&az<56)||(az<6&&ax<56)){
      if(y===40||((ax===0||ax===5||az===0||az===5)&&y===41))b=B.BRICKS;
      if((ax%16<3&&az<6||az%16<3&&ax<6)&&y<40)b=B.BRICKS;
      if(y>41&&y<45)b=0;
     }
    }else{
     if(y===0)b=B.BEDROCK;
     else if(y<=h){b=y===h?(biome==='desert'||h<SEA+1?B.SAND:h>65?B.SNOW:B.GRASS):y>h-4?(biome==='desert'?B.SAND:B.DIRT):B.STONE;
      if(y>2&&y<h-4){
       const cave=Math.abs(noise(wx/24,y/16,wz/24,s+21)-.5)<.07&&noise(wx/42,y/27,wz/42,s+24)>.49;
       const ravine=Math.abs(noise(wx/70,0,wz/70,s+38)-.5)<.012&&y>14&&y<h-2;
       if(cave||ravine)b=y<9?(y===8&&noise(wx/12,0,wz/12,s+41)>.55?B.OBSIDIAN:B.LAVA):0;
       else if(b===B.STONE){let r=hash(Math.floor(wx/2),Math.floor(y/2),Math.floor(wz/2),s+35);
        if(y<18&&r>.992)b=B.DIAMOND;else if(y<18&&r>.98)b=B.REDSTONE;else if(y<28&&r>.973)b=B.LAPIS;
        else if(y<32&&r>.96)b=B.GOLD;else if(y<55&&r>.925)b=B.IRON;else if(r>.88)b=B.COAL;
        if(biome==='mountains'&&y<48&&hash(wx,y,wz,s+36)>.995)b=B.EMERALD;
       }
      }
     }else if(y<=SEA)b=B.WATER;
    }
    out[index(x,y,z)]=b;
   }
  }
  if(dimension==='overworld')for(let gz=Math.floor((cz*16-3)/5);gz<=Math.floor((cz*16+18)/5);gz++)for(let gx=Math.floor((cx*16-3)/5);gx<=Math.floor((cx*16+18)/5);gx++){
   const wx=gx*5+Math.floor(hash(gx,0,gz,s+11)*4),wz=gz*5+Math.floor(hash(gx,0,gz,s+12)*4),c=this.column(wx,wz);
   if(c.biome!=='forest'&&c.biome!=='plains'||c.height<=SEA+1||hash(gx,0,gz,s+13)>(c.biome==='forest'?.58:.065))continue;
   const h=4+Math.floor(hash(gx,0,gz,s+14)*3);
   for(let dy=1;dy<h+3;dy++)for(let dz=-2;dz<=2;dz++)for(let dx=-2;dx<=2;dx++){
    const x=wx+dx-cx*16,z=wz+dz-cz*16,y=c.height+dy;
    if(x<0||x>=16||z<0||z>=16||y>=HEIGHT)continue;
    if(!dx&&!dz&&dy<=h)out[index(x,y,z)]=B.LOG;
    else if(dy>=h-1&&Math.abs(dx)+Math.abs(dz)+(dy===h+2?2:0)<5&&!out[index(x,y,z)])out[index(x,y,z)]=B.LEAVES;
   }
  }
  return out;
 }
}
export function newPlayer(terrain,mode='survival'){
 let x=8,z=8; for(let r=0;r<100;r++){let c=terrain.column(x,z);if(c.height>SEA+2&&c.biome!=='mountains'){const a=terrain.generate(Math.floor(x/16),Math.floor(z/16));if(!a[index(local(x),c.height+1,local(z))]&&!a[index(local(x),c.height+2,local(z))])break;}x+=7;z+=3;}
 return {x:x+.5,y:terrain.column(x,z).height+1.05,z:z+.5,vx:0,vy:0,vz:0,yaw:0,pitch:0,health:20,hunger:20,oxygen:20,mode,dimension:'overworld',inventory:Array(36).fill(null),armor:{},selected:0,ground:false,flight:false,deaths:0,spawn:{x:x+.5,y:terrain.column(x,z).height+1.05,z:z+.5}};
}
export function addItem(inv,id,n=1,dur){if(!ITEMS[id]||n<1)return false;const max=ITEMS[id].durability||ITEMS[id].armor?1:64;let room=inv.reduce((t,s)=>t+(!s?max:s.id===id&&!s.dur?max-s.n:0),0);if(room<n)return false;for(let i=0;i<inv.length&&n;i++){let q=inv[i];if(q?.id===id&&!q.dur&&q.n<max){let v=Math.min(n,max-q.n);q.n+=v;n-=v;}}for(let i=0;i<inv.length&&n;i++)if(!inv[i]){let v=Math.min(n,max);inv[i]={id,n:v,...(ITEMS[id].durability?{dur:dur??ITEMS[id].durability}:{})};n-=v;}return true;}
export const countItem=(inv,id)=>inv.reduce((t,s)=>t+(s?.id===id?s.n:0),0);
export function removeItem(inv,id,n){if(countItem(inv,id)<n)return false;for(let i=0;i<inv.length&&n;i++)if(inv[i]?.id===id){let a=Math.min(n,inv[i].n);inv[i].n-=a;n-=a;if(!inv[i].n)inv[i]=null;}return true;}
export const solid=id=>!!BLOCKS[id]?.solid;
export const PLAYER_RADIUS=.3,PLAYER_HEIGHT=1.8;
const COLLISION_EPS=1e-7;
export function collides(get,x,y,z){for(let X=Math.floor(x-PLAYER_RADIUS+COLLISION_EPS);X<=Math.floor(x+PLAYER_RADIUS-COLLISION_EPS);X++)for(let Y=Math.floor(y+COLLISION_EPS);Y<=Math.floor(y+PLAYER_HEIGHT-COLLISION_EPS);Y++)for(let Z=Math.floor(z-PLAYER_RADIUS+COLLISION_EPS);Z<=Math.floor(z+PLAYER_RADIUS-COLLISION_EPS);Z++)if(solid(get(X,Y,Z)))return true;return false;}
// Recover older saved positions, or a player enclosed by a world edit, without
// changing their inventory, spawn, dimension or world generation.
export function recoverPlayer(p,get){
 if(!collides(get,p.x,p.y,p.z))return false;
 let best=null,score=Infinity;
 const consider=(x,y,z)=>{const distance=(x-p.x)**2+(y-p.y)**2+(z-p.z)**2;if(distance<score&&distance>COLLISION_EPS&&!collides(get,x,y,z)){best={x,y,z};score=distance;}};
 for(let x=Math.floor(p.x-PLAYER_RADIUS);x<=Math.floor(p.x+PLAYER_RADIUS);x++)for(let y=Math.floor(p.y);y<=Math.floor(p.y+PLAYER_HEIGHT);y++)for(let z=Math.floor(p.z-PLAYER_RADIUS);z<=Math.floor(p.z+PLAYER_RADIUS);z++)if(solid(get(x,y,z))){consider(x-PLAYER_RADIUS,p.y,p.z);consider(x+1+PLAYER_RADIUS,p.y,p.z);consider(p.x,y-PLAYER_HEIGHT,p.z);consider(p.x,y+1,p.z);consider(p.x,p.y,z-PLAYER_RADIUS);consider(p.x,p.y,z+1+PLAYER_RADIUS);}
 if(!best)for(let y=-4;y<=4;y++)for(let z=-3;z<=3;z++)for(let x=-3;x<=3;x++)consider(Math.floor(p.x)+x+.5,Math.floor(p.y)+y,Math.floor(p.z)+z+.5);
 if(!best)return false;Object.assign(p,best,{vx:0,vy:0,vz:0});p.ground=collides(get,p.x,p.y-.0001,p.z);return true;
}
// Sweep the complete player box to the first solid voxel boundary. The same
// function is used for simulation and client/server position reconciliation.
export function moveWithCollisions(p,delta,get){
 const moved={x:0,y:0,z:0};if(collides(get,p.x,p.y,p.z)&&!recoverPlayer(p,get))return moved;
 for(const axis of ['x','z','y']){
  const amount=Math.max(-64,Math.min(64,Number(delta[axis])||0));if(!amount)continue;
  const positive=amount>0,min=axis==='y'?0:-PLAYER_RADIUS,max=axis==='y'?PLAYER_HEIGHT:PLAYER_RADIUS;
  const side=p[axis]+(positive?max:min),start=positive?Math.floor(side-COLLISION_EPS)+1:Math.floor(side+COLLISION_EPS)-1,end=Math.floor(side+amount+(positive?-COLLISION_EPS:COLLISION_EPS));
  const others=['x','y','z'].filter(a=>a!==axis),ranges=others.map(a=>[Math.floor(p[a]+(a==='y'?0:-PLAYER_RADIUS)+COLLISION_EPS),Math.floor(p[a]+(a==='y'?PLAYER_HEIGHT:PLAYER_RADIUS)-COLLISION_EPS)]);
  let allowed=amount;
  scan:for(let cell=start;positive?cell<=end:cell>=end;cell+=positive?1:-1)for(let a=ranges[0][0];a<=ranges[0][1];a++)for(let b=ranges[1][0];b<=ranges[1][1];b++){
   const point={[axis]:cell,[others[0]]:a,[others[1]]:b};if(solid(get(point.x,point.y,point.z))){allowed=positive?Math.max(0,cell-max-p[axis]):Math.min(0,cell+1-min-p[axis]);break scan;}
  }
  p[axis]+=allowed;moved[axis]=allowed;
 }
 return moved;
}
export function physics(p,input,dt,get){
 dt=Math.min(.05,dt); if(p.health<=0||dt<=0)return;
 if(collides(get,p.x,p.y,p.z)&&!recoverPlayer(p,get)){p.vx=p.vy=p.vz=0;return;}
 const water=[B.WATER,B.LAVA].includes(get(Math.floor(p.x),Math.floor(p.y+.8),Math.floor(p.z)));
 const sprint=!!input.sprint&&p.hunger>5,speed=p.mode==='creative'&&p.flight?11:water?2.5:sprint?5.7:4.1;
 let f=(input.forward?1:0)-(input.back?1:0),r=(input.right?1:0)-(input.left?1:0),l=Math.hypot(f,r)||1;f/=l;r/=l;
 p.vx=(Math.sin(p.yaw)*f+Math.cos(p.yaw)*r)*speed;p.vz=(-Math.cos(p.yaw)*f+Math.sin(p.yaw)*r)*speed;
 if(p.mode==='creative'&&p.flight)p.vy=((input.jump?1:0)-(input.down?1:0))*speed;
 else {p.vy=Math.max(-40,p.vy-(water?6:24)*dt);if(input.jump&&(p.ground||water))p.vy=water?4:8.3;}
 const prevVy=p.vy,delta={x:p.vx*dt,y:p.vy*dt,z:p.vz*dt},moved=moveWithCollisions(p,delta,get),landed=delta.y<0&&moved.y>delta.y+COLLISION_EPS;
 for(const axis of ['x','y','z'])if(Math.abs(delta[axis]-moved[axis])>COLLISION_EPS)p['v'+axis]=0;
 p.ground=landed||(p.vy<=0&&collides(get,p.x,p.y-.0001,p.z));
 if(landed&&prevVy<-12&&p.mode==='survival'&&!water)p.health=Math.max(0,p.health-Math.floor((prevVy*prevVy/48)-3));
 p.x=Math.max(-1000000,Math.min(1000000,p.x));p.z=Math.max(-1000000,Math.min(1000000,p.z));
}
export function raycast(get,origin,dir,max=6){let prev=null;for(let t=0;t<=max;t+=.04){let x=Math.floor(origin.x+dir.x*t),y=Math.floor(origin.y+dir.y*t),z=Math.floor(origin.z+dir.z*t),id=get(x,y,z);if(id&&id!==B.WATER&&id!==B.LAVA)return{x,y,z,id,previous:prev,distance:t};prev={x,y,z};}return null;}
export const direction=(yaw,pitch)=>({x:Math.sin(yaw)*Math.cos(pitch),y:Math.sin(pitch),z:-Math.cos(yaw)*Math.cos(pitch)});
export function miningSeconds(id,tool){const b=BLOCKS[id];if(!b||b.hardness>=999)return Infinity;const t=ITEMS[tool],isRock=[B.STONE,B.COBBLE,B.FURNACE,B.OBSIDIAN,B.NETHERRACK,B.BRICKS,B.QUARTZ].includes(id)||id>=10&&id<=16,kind=isRock?'pickaxe':[B.LOG,B.PLANKS,B.TABLE,B.CHEST].includes(id)?'axe':[B.GRASS,B.DIRT,B.SAND,B.SOUL,B.SNOW].includes(id)?'shovel':null;return Math.max(.12,b.hardness*(isRock?1.4:.8)/(t?.tool===kind?t.speed:1));}
