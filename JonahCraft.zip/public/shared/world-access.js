// Old worlds remain shared. A private world is accessible only to its creator's account ID.
export const worldAccess=world=>world?.access==='singleplayer'?'singleplayer':'multiplayer';
export const canJoinWorld=(world,user)=>worldAccess(world)!=='singleplayer'||!!user&&world.creator===user.id;
