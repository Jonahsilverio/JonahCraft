// Original 16x16 art. Texture generation does not change world generation or saves.
export function paintAtlas(canvas,{B,hash}){
 const q=canvas.getContext('2d');q.imageSmoothingEnabled=false;q.clearRect(0,0,128,128);
 for(let tile=0;tile<64;tile++){
  const X=tile%8*16,Y=Math.floor(tile/8)*16,id=({33:B.DIRT,34:B.LOG,35:B.FURNACE,36:B.TABLE,37:B.CHEST})[tile]??tile;
  q.save();q.beginPath();q.rect(X,Y,16,16);q.clip();
  const random=(x,y,s=0)=>hash(x,y,tile,1073+s),fill=(x,y,w,h,c)=>{q.fillStyle=c;q.fillRect(X+x,Y+y,w,h);};
  const rgb=(r,g,b,n)=>`rgb(${r+n} ${g+n} ${b+n})`;
  const colors=({1:[118,151,66],2:[133,96,65],3:[133,134,127],4:[218,207,158],5:[48,95,175],6:[107,83,51],7:[71,113,42],8:[177,139,86],9:[61,62,58],17:[224,86,12],18:[119,124,114],19:[152,113,65],20:[120,125,118],21:[160,116,57],22:[135,96,43],23:[32,26,43],24:[100,44,153],25:[115,50,44],26:[100,79,57],27:[115,50,44],28:[187,139,62],29:[65,36,42],30:[183,220,223],31:[231,237,233],32:[223,222,209]})[id]||[131,133,126];
  for(let y=0;y<16;y++)for(let x=0;x<16;x++){const n=Math.floor((random(Math.floor(x/2),Math.floor(y/2))-.5)*17+(random(x,y,21)-.5)*10);fill(x,y,1,1,rgb(...colors,n));}
  if(tile===B.GRASS){for(let i=0;i<24;i++){const x=Math.floor(random(i,1)*15),y=Math.floor(random(i,2)*15);fill(x,y,1,2,i%3?'#8fa852':'#6c8b3b');}}
  if(id===B.DIRT){for(let i=0;i<20;i++){const x=Math.floor(random(i,3)*15),y=Math.floor(random(i,4)*15);if(tile!==33||y>5)fill(x,y,1+(i%2),1,i%3?'#a27b53':'#66513c');}}
  if(tile===33){for(let x=0;x<16;x++){const d=2+Math.floor(random(Math.floor(x/2),1)*3);for(let y=0;y<d;y++)fill(x,y,1,1,['#789c45','#88a34e','#698b3d'][Math.floor(random(x,y,3)*3)]);if(x%4===0)fill(x,d,1,2,'#6f883c');}}
  if(id===B.STONE||tile>=10&&tile<=16||id===B.FURNACE){for(let i=0;i<14;i++){const x=Math.floor(random(i,4)*15),y=Math.floor(random(i,5)*16);fill(x,y,2+(i%3),1,i%2?'#a2a39a':'#73766f');}}
  if(tile===B.LOG){for(let x=0;x<16;x++){const col=['#6d5434','#8d7046','#56452f','#7b613c'][Math.floor(random(x,0)*4)];for(let y=0;y<16;y++)if(random(x,Math.floor(y/5),3)>.2)fill(x,y,1,1,col);}fill(3,5,3,5,'#57462d');fill(4,6,1,3,'#a38350');fill(11,9,2,6,'#4f412b');}
  if(tile===34){fill(0,0,16,16,'#695032');fill(1,1,14,14,'#bd9c63');for(let i=2;i<8;i+=2){q.strokeStyle=i%4?'#967847':'#aa8a53';q.lineWidth=1;q.strokeRect(X+i+.5,Y+i+.5,15-i*2,15-i*2);}fill(7,7,2,2,'#8b6d40');}
  if([B.PLANKS,B.TABLE,B.CHEST,36,37].includes(tile)){fill(0,0,16,16,'#b9955d');for(let row=0;row<4;row++){fill(0,row*4+3,16,1,'#856339');fill(0,row*4,16,1,'#c7a66c');fill(row%2?4:11,row*4,1,4,'#937342');for(let i=0;i<4;i++)fill(Math.floor(random(i,row)*13),row*4+1+i%2,3,1,i%2?'#af8b52':'#c1a063');}}
  if(tile===B.TABLE){fill(1,5,14,2,'#6c4e2c');fill(3,8,2,7,'#6b4d2d');fill(11,8,2,7,'#6b4d2d');fill(6,8,4,4,'#957144');}
  if(tile===36){for(const [x,y,w,h]of [[0,0,16,2],[0,14,16,2],[0,0,2,16],[14,0,2,16],[5,3,1,10],[10,3,1,10],[3,5,10,1],[3,10,10,1]])fill(x,y,w,h,'#674a2c');}
  if([B.CHEST,37].includes(tile)){for(const [x,y,w,h]of [[0,0,16,2],[0,14,16,2],[0,0,2,16],[14,0,2,16],[1,6,14,2]])fill(x,y,w,h,'#4d391f');if(tile===37){fill(7,6,3,5,'#ded6ae');fill(8,8,1,2,'#797155');}}
  if(tile===35){fill(2,2,12,4,'#41463e');fill(3,3,10,2,'#222821');fill(2,9,12,5,'#484e44');fill(3,10,10,3,'#1b221b');fill(4,12,8,1,'#6d7566');}
  if(tile===B.COBBLE||tile===B.BRICKS){fill(0,0,16,16,tile===B.COBBLE?'#565c51':'#281b21');for(let row=0;row<4;row++)for(let col=-1;col<3;col++){const x=col*7+(row%2?3:0),y=row*4;fill(x+1,y+1,6,3,tile===B.COBBLE?['#92988b','#858d80','#777f72'][Math.floor(random(col,row)*3)]:['#57313a','#65373f','#472b33'][Math.floor(random(col,row)*3)]);fill(x+1,y+1,5,1,tile===B.COBBLE?'#a1a897':'#70434b');}}
  if(tile>=10&&tile<=16||tile===B.QUARTZ){const ore=({10:['#252a25','#454c40'],11:['#c8a085','#e1bba0'],12:['#c5a02c','#f6d962'],13:['#a72b2c','#df4840'],14:['#294b9b','#547ed0'],15:['#3dafa5','#91e7d2'],16:['#2c9752','#68d88a'],27:['#c5b5a2','#f0e2cc']})[tile];for(const [x,y]of [[2,3],[9,2],[6,8],[2,12],[12,10]]){fill(x,y,3,3,ore[0]);fill(x,y,2,1,ore[1]);fill(x+1,y+1,2,1,ore[1]);}}
  if(tile===B.LEAVES){fill(0,0,16,16,'#426e28');for(let i=0;i<32;i++){const x=Math.floor(random(i,3)*16),y=Math.floor(random(i,4)*16);fill(x,y,2+(i%2),2,['#64943d','#527e30','#345d23','#78a248'][i%4]);}for(let i=0;i<18;i++){const x=Math.floor(random(i,6)*15),y=Math.floor(random(i,7)*15);q.clearRect(X+x,Y+y,1+(i%3===0),1+(i%4===0));}}
  if(tile===B.GLASS){q.clearRect(X,Y,16,16);fill(0,0,16,1,'#b7d7dc');fill(0,15,16,1,'#a2c7cf');fill(0,0,1,16,'#a2c7cf');fill(15,0,1,16,'#d5e9e8');for(let i=0;i<4;i++){fill(3+i,5+i,1,1,'#d5eeee88');fill(8+i,8+i,1,1,'#d5eeee66');}}
  if(tile===B.WATER){for(let y=0;y<16;y+=4){const x=Math.floor(random(y,0)*10);fill(x,y,4,1,'#5a8fc733');fill((x+7)%12,y+2,3,1,'#284d8c33');}}
  if(tile===B.LAVA||tile===B.GLOWSTONE){for(let i=0;i<22;i++){const x=Math.floor(random(i,4)*14),y=Math.floor(random(i,5)*14);fill(x,y,2,2,tile===B.LAVA?'#ffbc2d':'#f6d48a');fill(x,y+2,3,1,tile===B.LAVA?'#c84612':'#92602e');}}
  if(tile===B.TORCH){fill(0,0,16,16,'#99733f');fill(0,0,16,7,'#ffb828');fill(2,0,12,4,'#fff0a6');fill(0,8,16,2,'#6c4f2c');}
  if(tile===B.PORTAL){for(let y=0;y<16;y++)for(let x=0;x<16;x++)if(Math.sin(x*.8+y*.4)+Math.cos(y*.6-x*.2)>1)fill(x,y,1,1,'#be75d9');}
  if(tile===B.OBSIDIAN){for(let i=0;i<12;i++)fill(Math.floor(random(i,2)*14),Math.floor(random(i,3)*14),2,1,i%2?'#4f3c61':'#181823');}
  if(tile===B.WOOL){for(let y=0;y<16;y+=4)for(let x=0;x<16;x+=4){fill(x,y,3,1,'#f0eee4');fill(x+2,y+2,2,1,'#c7c6b8');}}
  if(tile>=38&&tile<=40){
   q.clearRect(X,Y,16,16);
   if(tile===38){for(let i=0;i<11;i++){const x=1+Math.floor(random(i,0)*14),h=4+Math.floor(random(i,1)*9);fill(x,16-h,1,h,['#6e963e','#92af53','#527e30'][i%3]);if(i%2)fill(x-1,16-h+2,1,Math.max(1,h-4),i%3?'#779e43':'#9bb85d');}}
   else{fill(7,5,1,11,'#4e7b31');fill(4,10,3,1,'#759a43');fill(5,11,2,2,'#5e8938');fill(8,8,3,1,'#5e8938');const petal=tile===39?'#c94a36':'#e1bc42';fill(5,2,5,5,petal);fill(4,3,7,3,petal);fill(6,3,3,2,tile===39?'#e98155':'#f7db6a');}
  }
  q.restore();
 }
}
