// Original 16×16 pixel art, painted in code. No Minecraft textures are used.
export function paintAtlas(canvas,{B,BLOCKS,hash}){
 const ctx=canvas.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,128,128);
 for(let tile=0;tile<64;tile++){
  const X=tile%8*16,Y=Math.floor(tile/8)*16,id=tile<33?tile:({33:B.DIRT,34:B.LOG,35:B.FURNACE,36:B.TABLE,37:B.CHEST}[tile]??B.STONE);
  const fill=(x,y,w,h,color)=>{ctx.fillStyle=color;ctx.fillRect(X+x,Y+y,w,h);};
  const r=(x,y,s=0)=>hash(x,y,tile,9187+s);
  const palette=({[B.GRASS]:['#67a637','#78b346','#55932f','#8abb50'],[B.DIRT]:['#855a3b','#936442','#a2724d','#694a33'],[B.STONE]:['#898986','#979793','#777773','#a3a29c'],[B.SAND]:['#dfd39a','#e9dda6','#d1c28c','#f0e5b3'],[B.LEAVES]:['#3f7b2e','#528d37','#346b28','#669844'],[B.LOG]:['#765335','#86603b','#5c422d','#986d45'],[B.PLANKS]:['#b78b51','#c69a61','#aa7c45','#d2a970'],[B.WATER]:['#386acb','#3974d1','#427bd3','#3263c1'],[B.NETHERRACK]:['#79352e','#8c4138','#a25245','#622c2a'],[B.SOUL]:['#65503c','#735d47','#4f4032','#82664b'],[B.OBSIDIAN]:['#211c2f','#30253e','#422e50','#171723'],[B.BRICKS]:['#3b222b','#4d2c36','#60343a','#301f28'],[B.SNOW]:['#e9eeee','#f7faf8','#d9e3e4','#e1e9eb'],[B.WOOL]:['#e1ded2','#f0ebdf','#d1cec4','#e8e4d7'],[B.GLOWSTONE]:['#d7a740','#f4d475','#aa7335','#e8bb58'],[B.LAVA]:['#f18a12','#ffbf22','#e14c0e','#ffc937'],[B.PORTAL]:['#5d208f','#8a32b9','#b44ee0','#441668']})[id]||['#898783','#99958e','#77766f','#aaa59b'];
  // Larger pixel clusters keep surfaces readable at a distance, with fine grain close up.
  for(let y=0;y<16;y++)for(let x=0;x<16;x++){const band=Math.floor(r(Math.floor(x/2),Math.floor(y/2))*4),p=r(x,y,11)>.85?(band+1)%4:band;fill(x,y,1,1,palette[p]);}
  const stone=()=>{for(let y=0;y<16;y++)for(let x=0;x<16;x++)fill(x,y,1,1,['#81827e','#92928c','#747671','#a0a199'][Math.floor(r(Math.floor(x/3)+Math.floor(y/4),Math.floor(y/2),31)*4)]);for(let i=0;i<12;i++)fill(Math.floor(r(i,0,12)*14),Math.floor(r(i,1,12)*16),2,1,'#ffffff0b');};
  if(id===B.STONE||tile>=10&&tile<=16||tile===B.FURNACE||tile===35)stone();
  if(tile===B.GRASS){for(let i=0;i<38;i++){const x=Math.floor(r(i,3)*15),y=Math.floor(r(i,4)*15);fill(x,y,1,2,i%3?'#93bd57':'#4b8d2c');}}
  if(tile===33){for(let x=0;x<16;x++){const depth=3+Math.floor(r(x,8)*3);for(let y=0;y<depth;y++)fill(x,y,1,1,['#5b9434','#6ba43a','#7db24a'][Math.floor(r(x,y,90)*3)]);if(x%3===0)fill(x,depth,1,2,'#598730');}}
  if(tile===B.LOG){for(let x=0;x<16;x++){const base=['#68482e','#805a37','#92663d','#573e29'][Math.floor(r(x,0,5)*4)];for(let y=0;y<16;y++)if(r(x,y,4)>.22)fill(x,y,1,1,base);}fill(3,5,3,5,'#513a28');fill(4,6,1,3,'#956c45');fill(11,0,2,4,'#a07446');}
  if(tile===34){fill(0,0,16,16,'#785432');fill(1,1,14,14,'#bd965f');for(let i=2;i<8;i+=2){ctx.strokeStyle=i%4?'#987346':'#aa814c';ctx.lineWidth=1;ctx.strokeRect(X+i+.5,Y+i+.5,15-i*2,15-i*2);}fill(7,7,2,2,'#735335');}
  if([B.PLANKS,B.TABLE,B.CHEST,36,37].includes(tile)){fill(0,0,16,16,'#b98d54');for(let y=0;y<16;y++){for(let x=0;x<16;x++)if(r(Math.floor(x/3),y,7)>.6)fill(x,y,1,1,y%4?'#c49b62':'#d0a66d');if(y%4===3)fill(0,y,16,1,'#815b34');}for(let row=0;row<4;row++)fill(row%2?4:11,row*4,1,4,'#916737');}
  if(tile===36){fill(0,0,16,2,'#68452c');fill(0,14,16,2,'#68452c');fill(0,0,2,16,'#68452c');fill(14,0,2,16,'#68452c');for(let x=5;x<=10;x+=5)fill(x,3,1,10,'#684a30');for(let y=5;y<=10;y+=5)fill(3,y,10,1,'#684a30');fill(2,2,2,2,'#d6ac6a');}
  if(tile===B.TABLE){fill(1,5,14,2,'#65432b');fill(3,8,2,7,'#573e2a');fill(11,8,2,7,'#573e2a');fill(6,8,4,4,'#86613b');}
  if(tile===B.CHEST||tile===37){fill(0,0,16,2,'#4a331e');fill(0,14,16,2,'#4a331e');fill(0,0,2,16,'#4a331e');fill(14,0,2,16,'#4a331e');fill(1,6,14,2,'#4a331e');fill(7,6,3,5,'#d5cb91');fill(8,8,1,2,'#77663c');}
  if(tile===35){fill(2,2,12,4,'#333632');fill(3,3,10,2,'#1b1e1b');fill(2,9,12,5,'#3e423b');fill(3,10,10,3,'#171d18');fill(4,12,8,1,'#77796f');}
  if(tile===B.COBBLE||tile===B.BRICKS){fill(0,0,16,16,tile===B.COBBLE?'#53574f':'#251a23');for(let row=0;row<4;row++)for(let col=-1;col<3;col++){const x=col*7+(row%2?3:0),y=row*4;fill(x+1,y+1,6,3,tile===B.COBBLE?['#94958c','#858981','#777d73'][Math.floor(r(col,row)*3)]:['#4c2b35','#59313a','#66383e'][Math.floor(r(col,row)*3)]);fill(x+1,y+1,5,1,tile===B.COBBLE?'#acada01a':'#94504a33');}}
  if(tile>=10&&tile<=16||tile===B.QUARTZ){if(tile===B.QUARTZ){fill(0,0,16,16,'#864036');}const colors={10:['#262824','#41443d'],11:['#d2aa88','#a47d60'],12:['#f8d751','#c39a22'],13:['#ee3434','#a21f27'],14:['#3368d9','#2448a0'],15:['#65e6d9','#33b7ae'],16:['#49dc65','#269f44'],27:['#f0e5d5','#bcaa94']};for(let i=0;i<7;i++){const x=1+Math.floor(r(i,0,17)*12),y=1+Math.floor(r(i,1,17)*12);fill(x,y,3,2,colors[tile][1]);fill(x,y,2,1,colors[tile][0]);fill(x+1,y+1,2,2,colors[tile][0]);}}
  if(tile===B.LEAVES){for(let y=0;y<16;y+=3)for(let x=0;x<16;x+=3){fill(x,y,2,1,'#75a451');fill(x+1,y+1,2,2,'#2f6327');}for(let i=0;i<9;i++)ctx.clearRect(X+Math.floor(r(i,3)*16),Y+Math.floor(r(i,4)*16),1,1);}
  if(tile===B.GLASS){ctx.clearRect(X,Y,16,16);fill(0,0,16,1,'#badcdd');fill(0,15,16,1,'#97c4cf');fill(0,0,1,16,'#aacfd6');fill(15,0,1,16,'#d5f3f1');for(let i=0;i<5;i++){fill(3+i,4+i,1,1,'#dcf7faaa');fill(8+i,8+i,1,1,'#dcf7fa88');}}
  if(tile===B.WATER){for(let y=0;y<16;y+=4){const x=Math.floor(r(y,0)*10);fill(x,y,5,1,'#75a3e955');fill((x+7)%12,y+2,4,1,'#244db655');}}
  if(tile===B.LAVA||tile===B.GLOWSTONE){for(let i=0;i<18;i++){const x=Math.floor(r(i,4)*14),y=Math.floor(r(i,5)*14);fill(x,y,2,2,tile===B.LAVA?'#ffce3b':'#ffe6a0');fill(x,y+2,3,1,tile===B.LAVA?'#dd4a13':'#956335');}}
  if(tile===B.TORCH){fill(0,0,16,16,'#8d6135');fill(0,0,16,7,'#ffba2d');fill(2,0,12,4,'#ffeaa0');fill(0,8,16,2,'#a47c40');fill(4,10,3,6,'#c19a52');}
  if(tile===B.PORTAL){for(let y=0;y<16;y++)for(let x=0;x<16;x++)if(Math.sin(x*.8+y*.4)+Math.cos(y*.6-x*.2)>1)fill(x,y,1,1,'#d268e6');}
 }
}
