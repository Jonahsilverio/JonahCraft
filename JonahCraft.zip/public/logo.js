// An original chunky pixel wordmark for JonahCraft.
export function decorateTitle(home){
 const glyphs={J:['00111','00010','00010','00010','10010','10010','01100'],O:['01110','11011','11011','11011','11011','11011','01110'],N:['11011','11011','11111','11111','11111','11011','11011'],A:['01110','11011','11011','11111','11011','11011','11011'],H:['11011','11011','11011','11111','11011','11011','11011'],C:['01111','11000','11000','11000','11000','11000','01111'],R:['11110','11011','11011','11110','11100','11010','11011'],F:['11111','11000','11000','11110','11000','11000','11000'],T:['11111','01110','01110','01110','01110','01110','01110']};
 const canvas=document.createElement('canvas');canvas.width=616;canvas.height=94;canvas.className='title-logo';canvas.setAttribute('aria-label','JonahCraft');canvas.setAttribute('role','img');const c=canvas.getContext('2d');c.imageSmoothingEnabled=false;
 const pixels=[];[...'JONAHCRAFT'].forEach((letter,i)=>glyphs[letter].forEach((row,y)=>[...row].forEach((v,x)=>{if(v==='1')pixels.push([(i*6+x)*10+6,y*10+5]);})));
 function layer(dx,dy,color){c.fillStyle=color;for(const[x,y]of pixels)c.fillRect(x+dx,y+dy,10,10);}
 for(let i=15;i>=0;i--)for(const[dx,dy]of [[-2,0],[2,0],[0,-2],[0,2]])layer(i*.35+dx,i+dy,'#101010');
 for(let i=14;i>0;i--)layer(i*.35,i,['#303030','#3e3e3e','#4c4c4c'][i%3]);
 const g=c.createLinearGradient(0,5,0,75);g.addColorStop(0,'#f0f0e9');g.addColorStop(.42,'#c3c3bc');g.addColorStop(1,'#969994');layer(0,0,g);
 for(const[x,y]of pixels){c.fillStyle='#ffffff24';c.fillRect(x,y,10,1);if((x*3+y)%17<4){c.fillStyle='#55595155';c.fillRect(x+6,y+3,1,4);c.fillRect(x+5,y+6,2,1);}}
 home.querySelector('h1').replaceChildren(canvas);home.querySelector('.lede').textContent='Now with Singleplayer!';
}
