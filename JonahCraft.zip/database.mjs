import {DatabaseSync} from 'node:sqlite';

// Local builds remain dependency-free. Cloud builds use a local read replica;
// writes and transactions are committed to the remote primary by libSQL.
export async function openDatabase(path){
 const remoteURL=process.env.TURSO_DATABASE_URL;
 if(process.env.REQUIRE_REMOTE_DB==='1'&&!remoteURL)throw Error('Free cloud hosting requires TURSO_DATABASE_URL and TURSO_AUTH_TOKEN. Refusing to start with temporary-only saves.');
 if(!remoteURL&&process.env.JONAH_DB_DRIVER!=='libsql')return new DatabaseSync(path);
 if(remoteURL&&!process.env.TURSO_AUTH_TOKEN)throw Error('The private database authentication token is missing.');
 if(remoteURL&&!/^(libsql|https):\/\//.test(remoteURL))throw Error('Use a secure Turso database URL.');
 const {default:Database}=await import('libsql');
 const db=new Database(path,remoteURL?{syncUrl:remoteURL,authToken:process.env.TURSO_AUTH_TOKEN,syncPeriod:30,timeout:10000}:{timeout:5000});
 if(remoteURL)await db.sync();
 return db;
}
