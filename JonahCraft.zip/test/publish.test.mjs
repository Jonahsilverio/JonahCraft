import test from 'node:test';
import assert from 'node:assert/strict';
import {publishBoth,SITES} from '../integration/publish-both.mjs';

function fixture({denySecond=false,owner=true}={}){
 const catalogs=new Map(SITES.map(origin=>[origin,[{id:'existing-game',title:'Existing game',visibility:'public',kind:'browser',playUrl:origin+'/game/existing/'}]]));
 const calls=[];const fetchImpl=async(url,options={})=>{
  calls.push({url,options});const u=new URL(url),origin=u.origin,path=u.pathname;
  const reply=(v,status=200,headers={})=>new Response(JSON.stringify(v),{status,headers:{'Content-Type':'application/json',...headers}});
  if(origin==='https://game.test')return reply({ok:true,version:'0.1.0',ownerConfigured:owner});
  if(path.endsWith('/login'))return denySecond&&origin===SITES[1]?reply({error:'Login failed'},401):reply({ok:true},200,{'Set-Cookie':'jonah_creator=test-session; HttpOnly; Secure'});
  if(path.endsWith('/logout'))return reply({ok:true});
  if(path.endsWith('/catalog'))return reply(catalogs.get(origin));
  if(path.endsWith('/save')){const p=JSON.parse(options.body),games=catalogs.get(origin),id=p.id||'new-game';const game={...p,id,revision:'new-revision',kind:'link',playUrl:p.link};if(p.id)games.splice(games.findIndex(g=>g.id===id),1,game);else games.push(game);return reply(game);}
  return reply({error:'Unknown endpoint'},404);
 };return {fetchImpl,calls,catalogs};
}
test('Both websites get one verified link; repeated publication updates it and preserves other games',async()=>{
 const f=fixture();let result=await publishBoth({gameURL:'https://game.test',password:'temporary-fixture-value',fetchImpl:f.fetchImpl,log:()=>{}});assert.equal(result.length,2);
 await publishBoth({gameURL:'https://game.test',password:'temporary-fixture-value',fetchImpl:f.fetchImpl,log:()=>{}});
 for(const games of f.catalogs.values()){assert.equal(games.length,2);assert.equal(games.filter(g=>g.title==='JonahCraft').length,1);assert.equal(games[0].title,'Existing game');assert.equal(games[1].playUrl,'https://game.test/');}
});
test('A failed second login prevents publication to either website',async()=>{const f=fixture({denySecond:true});await assert.rejects(publishBoth({gameURL:'https://game.test',password:'temporary-fixture-value',fetchImpl:f.fetchImpl,log:()=>{}}));assert.equal(f.calls.filter(c=>c.url.endsWith('/save')).length,0);assert.ok(f.calls.some(c=>c.url===SITES[0]+'/api/arcade/logout'));});
test('An unconfigured game owner blocks publishing before arcade credentials are transmitted',async()=>{const f=fixture({owner:false});await assert.rejects(publishBoth({gameURL:'https://game.test',password:'temporary-fixture-value',fetchImpl:f.fetchImpl,log:()=>{}}),/private Jonah owner setup/);assert.equal(f.calls.length,1);});
