import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {randomBytes} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {Terrain,B,HEIGHT,index,newPlayer,physics,addItem,removeItem,ITEMS,countItem} from '../public/shared/game.js';
test('Seed generation is stable across instances, dimensions and negative chunks',()=>{
 const a=new Terrain('seed contract'),b=new Terrain('seed contract'),c=new Terrain('different');
 assert.deepEqual(a.generate(-2,3),b.generate(-2,3));assert.notDeepEqual(a.generate(0,0),c.generate(0,0));
 assert.deepEqual(a.generate(2,-3,'nether'),b.generate(2,-3,'nether'));assert.notDeepEqual(a.generate(0,0,'nether'),a.generate(0,0));
 const found=new Set();for(let z=0;z<5;z++)for(let x=0;x<5;x++)for(const id of a.generate(x,z))found.add(id);
 for(const id of [B.COAL,B.IRON,B.GOLD,B.REDSTONE,B.LAPIS,B.DIAMOND,B.WATER,B.LAVA,B.LOG])assert.ok(found.has(id),'Expected block '+id);
 for(let x=0;x<16;x++)assert.equal(a.generate(0,0)[index(x,0,0)],B.BEDROCK);
});
test('Inventory operations preserve counts and reject overflow; physics collides and applies falls',()=>{
 const inv=Array(36).fill(null);assert.ok(addItem(inv,'diamond',130));assert.equal(countItem(inv,'diamond'),130);assert.equal(inv[0].n,64);assert.ok(removeItem(inv,'diamond',65));assert.equal(countItem(inv,'diamond'),65);assert.equal(removeItem(inv,'diamond',66),false);assert.equal(addItem(inv,'diamond',4000),false);assert.equal(countItem(inv,'diamond'),65);
 const p={x:0.5,y:15,z:.5,vx:0,vy:0,vz:0,yaw:0,health:20,hunger:20,mode:'survival'};for(let i=0;i<100;i++)physics(p,{},.05,(x,y,z)=>y<=0?B.STONE:0);assert.ok(p.y>=.98&&p.y<1.2);assert.ok(p.health<20);assert.equal(p.ground,true);
});
test('Real server: secure accounts, owner authorization, two players, gameplay, persistence, Nether, backups and restart',async t=>{
 const data=mkdtempSync(join(tmpdir(),'jonahcraft-test-')),port=18089,origin=`http://127.0.0.1:${port}`,password=randomBytes(24).toString('hex');let child,token;
 async function start(setup=false){child=spawn(process.execPath,['server.mjs',...(setup?['--setup']:[])],{cwd:resolve(import.meta.dirname,'..'),env:{...process.env,DATA_DIR:data,PORT:String(port),HOST:'127.0.0.1',NODE_ENV:'test'},stdio:['ignore','pipe','pipe']});let output='',errors='';child.stderr.on('data',v=>errors+=v);child.stdout.on('data',v=>{output+=v;const m=output.match(/\/setup#([a-f0-9]{64})/);if(m)token=m[1];});for(let i=0;i<100;i++){if(child.exitCode!==null)throw Error(errors);try{if((await fetch(origin+'/api/status')).ok&&(!setup||token))return;}catch{}await delay(100);}throw Error('Server not ready: '+errors);}
 async function stop(){if(child?.exitCode===null){child.kill('SIGTERM');await new Promise(r=>child.once('exit',r));}}
 t.after(stop);await start(true);
 const client=()=>({cookie:'',async call(path,body,expected=200){const r=await fetch(origin+'/api/'+path,{headers:{Origin:origin,...(this.cookie?{Cookie:this.cookie}:{}),...(body!==undefined?{'Content-Type':'application/json'}:{})},...(body!==undefined?{method:'POST',body:JSON.stringify(body)}:{})});const v=await r.json();if(r.headers.get('set-cookie'))this.cookie=r.headers.get('set-cookie').split(';')[0];assert.equal(r.status,expected,`${path}: ${JSON.stringify(v)}`);return v;}});
 const owner=client(),guest=client(),other=client();const setup=await owner.call('setup',{token,password},201);assert.equal(setup.user.username,'Jonah');assert.equal(setup.user.owner,true);
 await other.call('register',{username:'jOnAh',password},403);await other.call('setup',{token,password},403);
 const registration=await guest.call('register',{username:'Builder',password},201);assert.equal(registration.user.owner,false);await guest.call('owner',undefined,403);
 const cookieBefore=guest.cookie;await guest.call('logout',{});await guest.call('login',{username:'builder',password:'incorrect-password'},401);await guest.call('login',{username:'builder',password});assert.notEqual(guest.cookie,cookieBefore);
 const raw=await fetch(origin+'/api/worlds',{method:'POST',headers:{Cookie:owner.cookie,Origin:'https://evil.invalid','Content-Type':'application/json'},body:'{}'});assert.equal(raw.status,403);
 const created=await owner.call('worlds',{name:'Integration test',seed:'qa-world-001',mode:'survival'},201),wid=created.id;
 await owner.call('join',{world:wid});await guest.call('join',{world:wid});let state=await guest.call('state');assert.equal(state.players.length,2);
 let checked=0;for(const text of ['/gamemode creative','/give diamond 64','/tp 0 70 0','/time day','/weather rain','/summon creeper','/kick Jonah','/ban Jonah','/unban Builder','/whitelist off','/save']){if(checked++===7)await delay(10100);await guest.call('action',{op:'chat',text},403);}
 await guest.call('action',{op:'creative_item',item:'diamond'},400);
 await guest.call('action',{op:'chat',text:'hello shared world'});assert.ok((await owner.call('state')).chat.some(q=>q.text==='hello shared world'));
 await owner.call('owner',{op:'command',text:'/give oak_log 3'});let r=await owner.call('action',{op:'craft',item:'planks'});assert.equal(countItem(r.player.inventory,'planks'),4);r=await owner.call('action',{op:'craft',item:'crafting_table'});assert.equal(countItem(r.player.inventory,'crafting_table'),1);await owner.call('action',{op:'craft',item:'diamond_sword'},400);
 // Find a naturally flat and clear patch using the same deterministic generator.
 const terrain=new Terrain('qa-world-001'),cache=new Map();let X,Z,Y,found=false;
 const generated=(x,z)=>{const key=Math.floor(x/16)+','+Math.floor(z/16);if(!cache.has(key))cache.set(key,terrain.generate(Math.floor(x/16),Math.floor(z/16)));return cache.get(key);};
 outer:for(let z=-100;z<200;z++)for(let x=-100;x<200;x++){const h=terrain.column(x,z).height;if(h<37||h>58)continue;let ok=true;for(let dx=-1;dx<=4;dx++)for(let dz=-1;dz<=3;dz++){if(terrain.column(x+dx,z+dz).height!==h){ok=false;break;}const chunk=generated(x+dx,z+dz);for(let dy=1;dy<8;dy++)if(chunk[index(((x+dx)%16+16)%16,h+dy,((z+dz)%16+16)%16)])ok=false;}if(ok){X=x;Z=z;Y=h;found=true;break outer;}}
 assert.ok(found,'flat test patch');
 await owner.call('owner',{op:'command',text:`/tp ${X+.5} ${Y+1.05} ${Z+.5}`});await owner.call('owner',{op:'command',text:'/gamemode creative'});
 const at={x:X+2,y:Y+1,z:Z},against={x:X+2,y:Y,z:Z};let p=(await owner.call('state')).player;let slot=p.inventory.findIndex(q=>q?.id==='crafting_table');await owner.call('action',{op:'swap',a:slot,b:0});await owner.call('action',{op:'select',slot:0});await owner.call('action',{op:'place',...at,against});
 await owner.call('owner',{op:'command',text:'/give cobblestone 16'});await owner.call('owner',{op:'command',text:'/give stick 4'});r=await owner.call('action',{op:'craft',item:'stone_pickaxe'});assert.equal(countItem(r.player.inventory,'stone_pickaxe'),1);
 let chunk=await owner.call(`chunk?x=${Math.floor(at.x/16)}&z=${Math.floor(at.z/16)}&d=overworld`);assert.ok(chunk.edits.some(q=>q[0]===at.x&&q[1]===at.y&&q[2]===at.z&&q[3]===B.TABLE));
 await owner.call('owner',{op:'command',text:'/tp Builder'}); // move near the second player, then return
 await owner.call('owner',{op:'command',text:`/tp ${X+.5} ${Y+1.05} ${Z+.5}`});
 // Mining timing and server-set item drops.
 await owner.call('owner',{op:'command',text:'/gamemode survival'});const dirt={x:X+1,y:Y,z:Z};await owner.call('action',{op:'mine_finish',...dirt},400);await owner.call('action',{op:'mine_start',...dirt});await owner.call('action',{op:'mine_finish',...dirt},400);await delay(650);await owner.call('action',{op:'mine_finish',...dirt});state=await owner.call('state');assert.ok(state.changes.some(q=>q.x===dirt.x&&q.y===dirt.y&&q.b===0));assert.ok(state.drops.length>0||countItem(state.player.inventory,'grass')>0);assert.ok((await guest.call('state')).changes.some(q=>q.x===dirt.x&&q.y===dirt.y&&q.b===0));
 // Move both clients to the changed area and compare authoritative block revisions.
 await owner.call('owner',{op:'command',text:'/gamemode creative Builder'});await owner.call('owner',{op:'command',text:`/tp ${X+.5} ${Y+1.05} ${Z+.5}`});await owner.call('owner',{op:'command',text:'/gamemode creative'});
 // Place chest and test serialized contents.
 await owner.call('action',{op:'creative_item',item:'chest'});const chest={x:X,y:Y+1,z:Z+2};await owner.call('action',{op:'place',...chest,against:{x:X,y:Y,z:Z+2}});await owner.call('owner',{op:'command',text:'/give diamond 5'});p=(await owner.call('state')).player;slot=p.inventory.findIndex(q=>q?.id==='diamond');r=await owner.call('action',{op:'container',...chest,move:'deposit',slot});assert.equal(countItem(r.container.inventory,'diamond'),5);let cs=r.container.inventory.findIndex(q=>q?.id==='diamond');r=await owner.call('action',{op:'container',...chest,move:'withdraw',slot:cs});assert.equal(countItem(r.player.inventory,'diamond'),5);
 await owner.call('action',{op:'creative_item',item:'furnace'});const furnace={x:X+2,y:Y+1,z:Z+2};await owner.call('action',{op:'place',...furnace,against:{x:X+2,y:Y,z:Z+2}});await owner.call('owner',{op:'command',text:'/give raw_iron 1'});await owner.call('owner',{op:'command',text:'/give coal 1'});p=(await owner.call('state')).player;slot=p.inventory.findIndex(q=>q?.id==='raw_iron');await owner.call('action',{op:'container',...furnace,move:'smelt',slot});await delay(8200);r=await owner.call('action',{op:'container',...furnace,move:'take'});assert.equal(countItem(r.player.inventory,'iron_ingot'),1);
 // Input is simulated on the server; forged position fields are ignored.
 const before=(await owner.call('state')).player;await owner.call('input',{forward:true,yaw:Math.PI,pitch:0,x:99999,health:9999});await delay(300);await owner.call('input',{yaw:0,pitch:0});const moved=(await owner.call('state')).player;assert.ok(Math.hypot(moved.x-before.x,moved.z-before.z)>.2);assert.ok(moved.x<99999);assert.ok(moved.health<=20);
 await owner.call('owner',{op:'command',text:`/tp ${X+.5} ${Y+1.05} ${Z+1.5}`});await owner.call('owner',{op:'command',text:'/summon pig'});state=await owner.call('state');const mob=state.mobs.at(-1);await owner.call('action',{op:'creative_item',item:'diamond_sword'});await owner.call('action',{op:'attack',mob:mob.id});assert.ok(!(await owner.call('state')).mobs.some(q=>q.id===mob.id));
 // Clear portal location 4 blocks ahead; core constructs a safe return pair.
 await owner.call('owner',{op:'command',text:`/tp ${X+.5} ${Y+1.05} ${Z+.5}`});await owner.call('input',{yaw:Math.PI/2,pitch:0});await delay(80);await owner.call('action',{op:'creative_item',item:'nether_key'});
 // Portal core requires clear air. Build it above the test patch to avoid a hillside.
 await owner.call('owner',{op:'command',text:`/tp ${X+.5} 80 ${Z+.5}`});await owner.call('action',{op:'flight'});await owner.call('action',{op:'ignite'});let s=(await owner.call('state')).player;const portalX=Math.floor(s.x+4);await owner.call('owner',{op:'command',text:`/tp ${portalX+.5} 81 ${Z+1.5}`});await owner.call('action',{op:'portal'});assert.equal((await owner.call('state')).player.dimension,'nether');await delay(5100);await owner.call('action',{op:'portal'});assert.equal((await owner.call('state')).player.dimension,'overworld');
 const backup=(await owner.call('owner',{op:'backup'})).backup;const saved=(await owner.call('state')).player;await owner.call('owner',{op:'command',text:'/give emerald 7'});
 await owner.call('owner',{op:'command',text:'/gamemode survival'});await owner.call('owner',{op:'command',text:`/tp ${X+1.5} 80 ${Z+1.5}`});await delay(3500);assert.equal((await owner.call('state')).player.health,0);r=await owner.call('action',{op:'respawn'});assert.equal(r.player.health,20);assert.equal(r.player.dimension,'overworld');assert.equal(r.player.inventory.filter(Boolean).length,0);
 await owner.call('owner',{op:'restore',backup});await owner.call('join',{world:wid});assert.equal(countItem((await owner.call('state')).player.inventory,'emerald'),0);
 await owner.call('owner',{op:'command',text:'/ban Builder'});await guest.call('me');await guest.call('state',undefined,401);await owner.call('owner',{op:'command',text:'/unban Builder'});await guest.call('login',{username:'Builder',password});await guest.call('join',{world:wid});
 await owner.call('owner',{op:'command',text:'/whitelist on'});await guest.call('state',undefined,403);await owner.call('owner',{op:'command',text:'/whitelist add Builder'});await guest.call('join',{world:wid});await guest.call('state');await owner.call('owner',{op:'command',text:'/whitelist off'});
 await owner.call('owner',{op:'command',text:'/save'});await stop();await start();await owner.call('login',{username:'Jonah',password});await owner.call('join',{world:wid});state=await owner.call('state');assert.equal(state.player.dimension,saved.dimension);assert.equal(countItem(state.player.inventory,'diamond'),5);
 await owner.call('owner',{op:'command',text:`/tp ${X+.5} ${Y+1.05} ${Z+.5}`});chunk=await owner.call(`chunk?x=${Math.floor(at.x/16)}&z=${Math.floor(at.z/16)}&d=overworld`);assert.ok(chunk.edits.some(q=>q[0]===at.x&&q[1]===at.y&&q[2]===at.z&&q[3]===B.TABLE));r=await owner.call('action',{op:'container',...chest});assert.ok(Array.isArray(r.container.inventory));
 const {DatabaseSync}=await import('node:sqlite');const db=new DatabaseSync(join(data,'jonahcraft.sqlite'));const row=db.prepare('SELECT * FROM users WHERE username=?').get('Jonah');assert.notEqual(row.password,password);assert.equal(row.password.length,128);assert.equal(row.salt.length,32);assert.equal(db.prepare('SELECT value FROM settings WHERE key=?').get('owner_id').value,row.id);db.close();
 console.log('Integration coverage passed: accounts, authorization, crafting, mining, storage, furnace, movement, combat, portals, backups, whitelist, ban, save/restart.');
});
