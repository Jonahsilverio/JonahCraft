import test from 'node:test';
import assert from 'node:assert/strict';
import {Worker} from 'node:worker_threads';
test('Terrain worker produces finite textured geometry and ambient shading',async t=>{
 const url=new URL('../public/mesh-worker.js',import.meta.url).href;
 const worker=new Worker(`const{parentPort}=require('node:worker_threads');globalThis.self=globalThis;globalThis.postMessage=data=>parentPort.postMessage(data);import(${JSON.stringify(url)}).then(()=>{parentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({ready:true});});`,{eval:true});t.after(()=>worker.terminate());
 const next=()=>new Promise((resolve,reject)=>{worker.once('message',resolve);worker.once('error',reject);});await next();worker.postMessage({type:'init',seed:'forest',dimension:'overworld'});const result=next();worker.postMessage({type:'generate',cx:0,cz:0,edits:[]});const mesh=await result;assert.equal(mesh.type,'mesh');assert.ok(mesh.opaque.p.length>0);assert.ok(mesh.opaque.p.every(Number.isFinite));assert.ok(mesh.opaque.c.every(v=>Number.isFinite(v)&&v>=0&&v<=1.2));assert.ok(new Set(mesh.opaque.c).size>10);assert.equal(mesh.voxels.length,16*16*96);
});
