import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {randomBytes} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';

test('Free hosting refuses temporary-only saves when cloud storage is required',async()=>{
 const p=spawn(process.execPath,['server.mjs'],{cwd:resolve(import.meta.dirname,'..'),env:{...process.env,DATA_DIR:mkdtempSync(join(tmpdir(),'jonah-free-guard-')),REQUIRE_REMOTE_DB:'1',TURSO_DATABASE_URL:'',TURSO_AUTH_TOKEN:''},stdio:['ignore','pipe','pipe']});let error='';p.stderr.on('data',c=>error+=c);const code=await new Promise(r=>p.once('exit',r));assert.notEqual(code,0);assert.match(error,/Refusing to start with temporary-only saves/);
});
test('Private HTTPS owner setup checks its one-time key and never logs it',async t=>{
 const token=randomBytes(32).toString('hex'),password=randomBytes(24).toString('hex'),origin='https://jonahcraft.test',base='http://127.0.0.1:18090';
 const p=spawn(process.execPath,['server.mjs'],{cwd:resolve(import.meta.dirname,'..'),env:{...process.env,DATA_DIR:mkdtempSync(join(tmpdir(),'jonah-free-setup-')),PORT:'18090',HOST:'127.0.0.1',NODE_ENV:'production',PUBLIC_URL:origin,OWNER_SETUP_TOKEN:token,TURSO_DATABASE_URL:'',TURSO_AUTH_TOKEN:'',REQUIRE_REMOTE_DB:''},stdio:['ignore','pipe','pipe']});let output='',errors='';p.stdout.on('data',c=>output+=c);p.stderr.on('data',c=>errors+=c);t.after(async()=>{if(p.exitCode===null){p.kill('SIGTERM');await new Promise(r=>p.once('exit',r));}});
 for(let i=0;i<100;i++){if(p.exitCode!==null)throw Error(errors);if(output.includes('JonahCraft ready:')&&output.includes('Private HTTPS owner setup is enabled'))break;await delay(100);}assert.ok(output.includes('Private HTTPS owner setup is enabled'));assert.equal(output.includes(token),false);assert.equal(output.includes(password),false);
 const post=async body=>{const r=await fetch(base+'/api/setup',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)});return {r,body:await r.json()};};
 let reply=await post({token:'0'.repeat(64),password});assert.equal(reply.r.status,403);
 reply=await post({token,password});assert.equal(reply.r.status,201);assert.equal(reply.body.user.username,'Jonah');assert.equal(reply.body.user.owner,true);assert.match(reply.r.headers.get('set-cookie'),/HttpOnly/);assert.match(reply.r.headers.get('set-cookie'),/Secure/);
 reply=await post({token,password});assert.equal(reply.r.status,403);
 const html=await (await fetch(base+'/setup')).text();assert.equal(html.includes(token),false);assert.equal(html.includes(password),false);assert.ok(html.includes('setup-key'));
});
