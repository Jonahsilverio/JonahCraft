import test from 'node:test';
import assert from 'node:assert/strict';
import {Worker} from 'node:worker_threads';
import {B,index} from '../public/shared/game.js';
test('A block change received before its chunk finishes loading survives the older chunk snapshot',async t=>{
 const url=new URL('../public/mesh-worker.js',import.meta.url).href;
 const worker=new Worker(`const{parentPort}=require('node:worker_threads');globalThis.self=globalThis;globalThis.postMessage=data=>parentPort.postMessage(data);import(${JSON.stringify(url)}).then(()=>{parentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({ready:true});});`,{eval:true});t.after(()=>worker.terminate());
 const next=()=>new Promise((resolve,reject)=>{worker.once('message',resolve);worker.once('error',reject);});await next();
 worker.postMessage({type:'init',seed:'forest',dimension:'overworld'});
 worker.postMessage({type:'edits',changes:[{d:'overworld',x:2,y:80,z:3,b:B.STONE,r:2}]});
 const message=next();worker.postMessage({type:'generate',cx:0,cz:0,revision:1,ticket:12,edits:[]});const mesh=await message;
 assert.equal(mesh.voxels[index(2,80,3)],B.STONE,'The renderer and collision data must include the newer block');assert.equal(mesh.ticket,12);assert.equal(mesh.revision,2);
});
