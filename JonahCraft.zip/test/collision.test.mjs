import test from 'node:test';
import assert from 'node:assert/strict';
import {B,physics,collides,moveWithCollisions,recoverPlayer} from '../public/shared/game.js';
import {ChunkEdits} from '../public/shared/chunk-edits.js';
const player=(p={})=>({x:.5,y:1,z:.5,vx:0,vy:0,vz:0,yaw:Math.PI/2,health:20,hunger:20,mode:'survival',ground:true,...p});
test('Walking and sprinting stop exactly at walls and stay on floors at different frame rates',()=>{
 const get=(x,y,z)=>y<1||x===2&&y<5?B.STONE:0;
 for(const dt of [1/144,1/60,1/20]){const p=player();for(let i=0;i<500;i++){physics(p,{forward:true,sprint:true},dt,get);assert.equal(collides(get,p.x,p.y,p.z),false);}assert.ok(Math.abs(p.x-1.7)<1e-6);assert.equal(p.y,1);assert.equal(p.ground,true);}
});
test('Position correction and Creative flight cannot tunnel through walls, corners, or negative chunk boundaries',()=>{
 const get=(x,y,z)=>y<1||x===2||z===2||x===-17?B.STONE:0;
 const p=player();moveWithCollisions(p,{x:30,z:30,y:-30},get);assert.equal(collides(get,p.x,p.y,p.z),false);assert.ok(p.x<=1.7&&p.z<=1.7);assert.equal(p.y,1);
 const negative=player({x:-15.5});moveWithCollisions(negative,{x:-30},get);assert.ok(Math.abs(negative.x+15.7)<1e-6);
 const flyer=player({mode:'creative',flight:true,y:3});for(let i=0;i<100;i++)physics(flyer,{forward:true,sprint:true},.05,get);assert.ok(flyer.x<=1.7);assert.equal(collides(get,flyer.x,flyer.y,flyer.z),false);
});
test('Jumping respects a low ceiling and falling lands without sinking into the floor',()=>{
 const ceiling=(x,y,z)=>y<1||y===3?B.STONE:0,p=player();physics(p,{jump:true},.05,ceiling);assert.ok(p.y>1);for(let i=0;i<100;i++){physics(p,{},.05,ceiling);assert.ok(p.y<=1.2+1e-6);assert.equal(collides(ceiling,p.x,p.y,p.z),false);}assert.equal(p.y,1);
 const falling=player({y:20,ground:false});for(let i=0;i<200;i++)physics(falling,{},.05,(x,y,z)=>y<1?B.STONE:0);assert.equal(falling.y,1);assert.ok(falling.health<20);assert.equal(falling.ground,true);
});
test('A saved position slightly inside a floor or wall is moved to nearby clear space',()=>{
 const get=(x,y,z)=>y<1||x===2&&y<5?B.STONE:0;
 for(const p of [player({y:.99}),player({x:1.9})]){const inv=[{id:'diamond',n:2}];p.inventory=inv;assert.ok(recoverPlayer(p,get));assert.equal(collides(get,p.x,p.y,p.z),false);assert.equal(p.inventory,inv);assert.ok(Math.abs(p.y-1)<1e-6);}
});
test('Chunk snapshots cannot overwrite more recent changes or reapply stale edits after reload',()=>{
 const ledger=new ChunkEdits();ledger.remember({x:-1,y:40,z:2,b:B.STONE,r:5});assert.equal(ledger.snapshot(-1,0,[],3)[0].b,B.STONE);ledger.snapshot(-1,0,[[-1,40,2,B.GLASS]],6);assert.equal(ledger.remember({x:-1,y:40,z:2,b:0,r:4}),false);assert.equal(ledger.snapshot(-1,0,[],2)[0].b,B.GLASS);ledger.forget(-1,0);assert.equal(ledger.snapshot(-1,0,[],7).length,0);
});
