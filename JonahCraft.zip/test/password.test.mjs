import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {randomBytes} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
test('Eight-character passwords work for owner setup and accounts; seven characters are rejected',async t=>{
 const origin='http://127.0.0.1:18093',data=mkdtempSync(join(tmpdir(),'jc-eight-')),password=randomBytes(4).toString('hex');let token,output='',errors='';
 const p=spawn(process.execPath,['server.mjs','--setup'],{cwd:resolve(import.meta.dirname,'..'),env:{...process.env,PORT:'18093',HOST:'127.0.0.1',DATA_DIR:data,NODE_ENV:'test',OWNER_SETUP_TOKEN:'',REQUIRE_REMOTE_DB:'',TURSO_DATABASE_URL:'',TURSO_AUTH_TOKEN:''},stdio:['ignore','pipe','pipe']});
 p.stdout.on('data',b=>{output+=b;token=output.match(/\/setup#([a-f0-9]{64})/)?.[1];});p.stderr.on('data',b=>errors+=b);t.after(async()=>{if(p.exitCode===null){p.kill('SIGTERM');await new Promise(r=>p.once('exit',r));}});
 for(let i=0;i<100;i++){if(p.exitCode!==null)throw Error(errors);if(token)break;await delay(75);}assert.ok(token);
 async function post(path,body,status){const r=await fetch(origin+'/api/'+path,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)}),value=await r.json();assert.equal(r.status,status,JSON.stringify(value));return {r,value};}
 await post('setup',{token,password:password.slice(0,7)},400);const owner=await post('setup',{token,password},201);assert.equal(owner.value.user.owner,true);assert.ok(owner.r.headers.get('set-cookie').includes('HttpOnly'));
 await post('register',{username:'EightTest',password:password.slice(0,7)},400);await post('register',{username:'EightTest',password},201);await post('login',{username:'EightTest',password},200);await post('login',{username:'Jonah',password},200);
 const html=await(await fetch(origin+'/setup')).text();assert.equal((html.match(/minlength="8"/g)||[]).length,2);assert.ok(!html.includes(password));
});
