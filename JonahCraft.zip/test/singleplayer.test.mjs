import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {randomBytes} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
test('Real singleplayer worlds are private, pause, and persist across logins and server restarts',async t=>{
 const data=mkdtempSync(join(tmpdir(),'jonahcraft-solo-')),port=18092,origin='http://127.0.0.1:'+port,password=randomBytes(24).toString('hex');let child;
 async function start(){let errors='';child=spawn(process.execPath,['server.mjs'],{cwd:resolve(import.meta.dirname,'..'),env:{...process.env,DATA_DIR:data,PORT:String(port),HOST:'127.0.0.1',NODE_ENV:'test',REQUIRE_REMOTE_DB:'',TURSO_DATABASE_URL:'',TURSO_AUTH_TOKEN:''},stdio:['ignore','pipe','pipe']});child.stderr.on('data',b=>errors+=b);for(let i=0;i<100;i++){if(child.exitCode!==null)throw Error(errors);try{if((await fetch(origin+'/api/status')).ok)return;}catch{}await delay(75);}throw Error('Server unavailable');}
 async function stop(){if(child?.exitCode===null){child.kill('SIGTERM');await new Promise(r=>child.once('exit',r));}}t.after(stop);
 const client=()=>({cookie:'',async call(path,body,status=200){const r=await fetch(origin+'/api/'+path,{headers:{Origin:origin,...(this.cookie?{Cookie:this.cookie}:{}),...(body!==undefined?{'Content-Type':'application/json'}:{})},...(body!==undefined?{method:'POST',body:JSON.stringify(body)}:{})});const value=await r.json();if(r.headers.get('set-cookie'))this.cookie=r.headers.get('set-cookie').split(';')[0];assert.equal(r.status,status,JSON.stringify(value));return value;}});
 await start();const alice=client(),bob=client();await alice.call('register',{username:'SoloAlice',password},201);await bob.call('register',{username:'SoloBob',password},201);
 const id=(await alice.call('worlds',{name:'Private test',seed:'solo-test',mode:'creative',access:'singleplayer'},201)).id;
 assert.ok((await alice.call('worlds?access=singleplayer')).worlds.some(w=>w.id===id));assert.ok(!(await bob.call('worlds')).worlds.some(w=>w.id===id));await bob.call('join',{world:id},403);
 const joined=await alice.call('join',{world:id});assert.equal(joined.world.access,'singleplayer');assert.equal(joined.player.owner,false);
 await alice.call('action',{op:'creative_item',item:'diamond'});await alice.call('input',{paused:true,yaw:0,pitch:0});const before=await alice.call('state');await delay(500);assert.equal((await alice.call('state')).time,before.time);
 await alice.call('input',{paused:false,yaw:0,pitch:0});await delay(250);assert.notEqual((await alice.call('state')).time,before.time);
 await alice.call('leave',{});await alice.call('logout',{});await alice.call('login',{username:'SoloAlice',password});await alice.call('join',{world:id});assert.equal((await alice.call('state')).player.inventory[0].id,'diamond');
 await stop();await start();await alice.call('login',{username:'SoloAlice',password});await alice.call('join',{world:id});assert.equal((await alice.call('state')).player.inventory[0].id,'diamond');await bob.call('login',{username:'SoloBob',password});await bob.call('join',{world:id},403);
 const shared=(await bob.call('worlds')).worlds.find(w=>w.access==='multiplayer');assert.ok(shared);await bob.call('join',{world:shared.id});await alice.call('leave',{});await alice.call('join',{world:shared.id});assert.equal((await bob.call('state')).players.length,2);
});
