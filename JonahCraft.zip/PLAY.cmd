@echo off
setlocal
cd /d "%~dp0"
set "JONAH_NODE=node"
where node >nul 2>nul
if errorlevel 1 (
  for /d %%D in ("%ProgramFiles%\WindowsApps\OpenAI.CodexPrimaryRuntime*") do if exist "%%~D\dependencies\node\bin\node.exe" set "JONAH_NODE=%%~D\dependencies\node\bin\node.exe"
)
"%JONAH_NODE%" launch.mjs
if errorlevel 1 (
  echo.
  echo JonahCraft needs Node.js 24 or newer. Install it from https://nodejs.org/
  echo If port 8088 is already in use, close the other JonahCraft server first.
  pause
)
