# Free cloud hosting — setup candidate

No paid Render service or persistent disk is needed for this configuration. It uses Render Free for the game process and Turso Free for durable account, world, inventory and backup records. The database adapter uses libSQL embedded replicas: reads are local and writes commit to the remote primary. A fresh server downloads its data from that primary before accepting requests.

The real Turso Free connection has passed game schema creation, remote writes, transaction commit and rollback, closing the database and reading the committed value from a fresh replica. The adapter has also passed local gameplay integration and HTTPS owner-bootstrap checks. Public server gameplay and restart verification are still pending deployment.

## Hosting configuration

- Render compute: Free, one instance, no disk, no paid upgrade or payment method.
- Runtime: Node.js 24.22.1.
- Build: `node unpack.mjs && npm ci --omit=dev`.
- Start: `node server.mjs`.
- `HOST=0.0.0.0`, `NODE_ENV=production`, `DATA_DIR=/tmp/jonahcraft`, `TRUST_PROXY=1`.
- `REQUIRE_REMOTE_DB=1` prevents accidentally starting with temporary-only saves.
- Store `TURSO_DATABASE_URL` and a database-scoped `TURSO_AUTH_TOKEN` only in Render's private runtime variables. Never add the authentication token to GitHub, this document, browser code or chat.
- `OWNER_SETUP_TOKEN` is a random, one-time setup capability held only in private server configuration. It enables the HTTPS owner form for fifteen minutes after startup. Once Jonah is created, owner setup locks permanently. The secret is never printed in server logs.

The owner password is entered privately on the game setup page. It is hashed with scrypt; neither a database token nor a setup key grants ordinary game owner permissions after account setup. Owner commands still require the immutable authenticated owner account ID.

Backups are stored in the database instead of temporary files. The existing private local backup format remains readable. Local desktop play still uses Node's built-in SQLite unless a cloud URL or test driver is explicitly selected.

## Free-plan limitations

Render Free sleeps after fifteen minutes without inbound traffic and takes about one minute to wake. Its local filesystem is disposable, so the remote database is mandatory. It provides 750 free instance-hours per month. Free traffic/build quotas can suspend service; without a payment method Render suspends instead of automatically billing overages. No uptime guarantee or large-player benchmark is claimed.

Turso currently lists a $0 plan with no credit card required, 5 GB storage, 500 million row reads, 10 million row writes and 3 GB sync allowance per month. Keep the account on Free and leave paid overages disabled. These are provider quotas, not promises of unlimited capacity.

Current references: [Render Free](https://render.com/docs/free), [Turso pricing](https://turso.tech/pricing), [libSQL driver](https://github.com/tursodatabase/libsql-js).

Neither Jonah's Games website is published with the game yet. Publication remains dependent on connecting the free database, testing persistence, completing Jonah's private owner setup and authenticating to the existing arcade Creator panels.
