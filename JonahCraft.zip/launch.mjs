import {spawn} from 'node:child_process';
import {dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const cwd=dirname(fileURLToPath(import.meta.url));
const server=spawn(process.execPath,['server.mjs','--setup'],{cwd,env:{...process.env,HOST:'127.0.0.1',PORT:'8088',NODE_ENV:'development',PUBLIC_URL:'http://127.0.0.1:8088'},stdio:['inherit','pipe','inherit']});
let output='',opened=false;
server.stdout.on('data',chunk=>{process.stdout.write(chunk);output+=chunk.toString();if(opened)return;const setup=output.match(/PRIVATE OWNER SETUP[^\n]*: (http:\/\/127\.0\.0\.1:8088\/setup#[a-f0-9]{64})/),ready=output.includes('Jonah is reserved')||output.includes('JonahCraft ready')&&!output.includes('PRIVATE OWNER SETUP');
 // Defer one turn so all startup lines can arrive before choosing the setup URL.
 setTimeout(()=>{if(opened)return;const link=output.match(/http:\/\/127\.0\.0\.1:8088\/setup#[a-f0-9]{64}/)?.[0]||'http://127.0.0.1:8088/';opened=true;let browser=process.platform==='win32'?spawn('cmd.exe',['/d','/c','start','',link],{stdio:'ignore',windowsHide:true}):spawn(process.platform==='darwin'?'open':'xdg-open',[link],{stdio:'ignore'});browser.on('error',()=>console.log('Open the local link above in your browser.'));browser.unref();},250);
});server.on('exit',code=>process.exit(code||0));process.on('SIGINT',()=>server.kill('SIGINT'));process.on('SIGTERM',()=>server.kill('SIGTERM'));
